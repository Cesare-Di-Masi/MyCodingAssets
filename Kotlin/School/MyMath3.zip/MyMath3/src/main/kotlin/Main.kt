fun main(args: Array<String>) {

    val n=MyMath3()
    println(n.calculateMCD(50,15))
    println(n.coprimi(78,14))
    println(n.amicabili(220,284))
    println(n.calculateFibonacciSuccession(10))
    println(n.calculateTribonacciSuccession(10))
    println(n.calculatemcm(15,50))
    println(n.calulateFactorial(6))
    println(n.calculateTime(12,3))
    println(n.calculateDistance(12,3))

}