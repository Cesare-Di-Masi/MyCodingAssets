class Subscription(nameValue:String, surnameValue:String, subTypeValue:Int, paymentStateValue:Boolean) {

    val PRICE_PER_MONTH:Int=50


    init {
        require(nameValue.isNotBlank()){"to make a subscription please digit your name"}
        require(surnameValue.isNotBlank()){"to make a subscription please digit your surname"}
        require(subTypeValue in 1..3){"there are only 3 types of subscription: 1(Type 1),6(Type 2),12 (Type 3) "}
    }

     private val name=nameValue
     private val surname=surnameValue
     private val subType=subTypeValue
     private var paymentState=paymentStateValue
     private var quoteCost:Int = 0

    fun paymentQuote(){

        check(!paymentState){"the quote has been already payed"}
        paymentState=true
        if (subType==1){
            quoteCost=PRICE_PER_MONTH
        }else{
            if (subType==2){
                val monthsDiscount=PRICE_PER_MONTH+5*(PRICE_PER_MONTH-(PRICE_PER_MONTH/10))
                quoteCost=monthsDiscount
            }else{
                val monthsDiscount=PRICE_PER_MONTH+5*(PRICE_PER_MONTH-(PRICE_PER_MONTH/10))+6*(PRICE_PER_MONTH-(15*PRICE_PER_MONTH/100))
                quoteCost=monthsDiscount
            }
        }

    }

    override fun toString(): String {
        return "Name:$name, Surname:$surname, Subscription type:$subType, The quote is payed?:$paymentState, payed:$quoteCost"
    }
}