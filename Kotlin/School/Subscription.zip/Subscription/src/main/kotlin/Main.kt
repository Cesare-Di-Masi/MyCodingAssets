fun main(args: Array<String>) {

    val sub1=Subscription("Elon","Musk",3,false)
    sub1.paymentQuote()
    println(sub1)
    val sub2=Subscription("Bill","Gates",1,false)
    sub2.paymentQuote()
    println(sub2)
    val sub3=Subscription("Jeff","Bezos",2,false)
    sub3.paymentQuote()
    println(sub3)

}