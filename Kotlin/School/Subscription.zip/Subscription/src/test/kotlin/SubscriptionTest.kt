import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import kotlin.IllegalArgumentException


class SubscriptionTest {

    @Test
    fun nameValueIsBlank() {
        assertThrows<IllegalArgumentException> { val subTest=Subscription("","ciao",1,false) }
    }

    @Test
    fun nameIsCorrect(){
        assertDoesNotThrow{val subTest=Subscription("ciao","ciao",1,false)}
    }

    @Test
    fun surnameValueIsBlank() {
        assertThrows<IllegalArgumentException> { val subTest=Subscription("ciao","",1,false) }
    }

    @Test
    fun surnameIsCorrect(){
        assertDoesNotThrow{val subTest=Subscription("ciao","ciao",1,false)}
    }

    @Test
    fun subTypeDoesNotExists(){
        assertThrows<IllegalArgumentException> { val subTest=Subscription("ciao","ciao",4,false) }
    }

    @Test
    fun subTypeExists(){
        assertDoesNotThrow{val subTest=Subscription("ciao","ciao",1,false)}
    }

}