class SoccerPlayer(playerNumber:Int, totGoalScoredValue:Array<Int>, totMinPlayedValue:Array<Int>) {

    init {
        require(playerNumber>0){"illegal player number"}
        for (i in totGoalScoredValue)
            require(i>=0){"Illegal amount of goal scored"}
        for (i in totMinPlayedValue)
            require(i>=0){"illegal amount of min played"}
    }

    val totGoalScored=totGoalScoredValue
    val totMinPlayed=totMinPlayedValue

}