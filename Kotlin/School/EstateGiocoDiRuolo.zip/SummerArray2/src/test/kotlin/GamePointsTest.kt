import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.*

class GamePointsTest(){

    @Test
    fun get_totPointsVal_Size_Is_Illegal_Smaller(){
        val arrayTest=Array<Int?>(51){1}
        assertThrows<IllegalArgumentException> {val test=GamePoints(arrayTest)}
    }

    @Test
    fun get_totPointsVal_Size_Is_Illegal_Bigger(){
        val arrayTest=Array<Int?>(53){1}
        assertThrows<IllegalArgumentException> {val test=GamePoints(arrayTest)}
    }

    @Test
    fun get_totPointsVal_Points_Is_Illegal_SmallerAfter(){
        val arrayTest=Array<Int?>(52){1}
        arrayTest[1]=0
        assertThrows<IllegalArgumentException> {val test=GamePoints(arrayTest)}
    }


    @Test
    fun get_totPointsVal_Size_Is_Legal(){
        val arrayTest=Array<Int?>(52){1}
        assertDoesNotThrow { val test=GamePoints(arrayTest) }
    }

    @Test
    fun get_totPointsVal_Points_Is_Legal(){
        val arrayTest=Array<Int?>(52){1}
        assertDoesNotThrow { val test=GamePoints(arrayTest) }
    }

    @Test
    fun addPoints_week_Is_Illegal_Negative(){
        val arrayTest=Array<Int?>(52){1}
        val test=GamePoints(arrayTest)
        assertThrows<IllegalArgumentException> { test.addPoints(2,-52) }
    }

    @Test
    fun addPoints_week_Is_Illegal_Bigger(){
        val arrayTest=Array<Int?>(52){1}
        val test=GamePoints(arrayTest)
        assertThrows<IllegalArgumentException> { test.addPoints(2,53) }
    }

    @Test
    fun addPoints_points_Is_Illegal_Negative(){
        val arrayTest=Array<Int?>(52){1}
        val test=GamePoints(arrayTest)
        assertThrows<IllegalArgumentException> { test.addPoints(-1,52) }
    }

    @Test
    fun addPoints_points_Is_Illegal_Smaller(){
        val arrayTest=Array<Int?>(52){2}
        val test=GamePoints(arrayTest)
        assertThrows<IllegalArgumentException> { test.addPoints(1,52) }
    }

    @Test
    fun addPoints_week_Is_Legal(){
        val arrayTest=Array<Int?>(52){2}
        val test=GamePoints(arrayTest)
        assertDoesNotThrow { test.addPoints(3,52) }
    }

    @Test
    fun addPoints_points_Is_Legal(){
        val arrayTest=Array<Int?>(52){2}
        val test=GamePoints(arrayTest)
        assertDoesNotThrow { test.addPoints(3,52) }
    }

    @Test
    fun addPoints_Is_Correct(){
        val arrayTest=Array<Int?>(52){2}
        val test=GamePoints(arrayTest)
        test.addPoints(3,52)
        assertEquals(3, test.totPoints[51])
    }

    @Test
    fun timesZeroPointsScored_Is_Correct(){
        val arrayTest=Array<Int?>(52){null}
        arrayTest[0]=1
        arrayTest[1]=1
        arrayTest[2]=1
        val test=GamePoints(arrayTest)
        assertEquals(2, test.timesZeroPointsScored())
    }

    @Test
    fun timesZeroPointsScored_Is_Correct_0(){
        val arrayTest=Array<Int?>(52){null}
        arrayTest[0]=2
        arrayTest[1]=3
        arrayTest[2]=4
        val test=GamePoints(arrayTest)
        assertEquals(0, test.timesZeroPointsScored())
    }

    @Test
    fun returnWeekScore_Is_Correct(){
        val arrayTest=Array<Int?>(52){null}
        arrayTest[0]=3
        val test=GamePoints(arrayTest)
        assertEquals(3,test.returnWeekScore(1))
    }

    @Test
    fun weeksFor100Points_Is_Correct(){
        val arrayTest=Array<Int?>(52){2}
        val test=GamePoints(arrayTest)
        assertEquals(50,test.weeksFor100Points())
    }

    @Test
    fun weeksFor100Points_Is_Correct_NotAchieved(){
        val arrayTest=Array<Int?>(52){1}
        val test=GamePoints(arrayTest)
        assertEquals(-1,test.weeksFor100Points())
    }

}