class GamePoints(totPointsVal:Array<Int?>) {

    init {
        require(totPointsVal.size==52){"the array size must be 52"}
        var pointMem:Int
        for (i in 1..<totPointsVal.size) {
            if (totPointsVal[i-1]!=null){
                pointMem=totPointsVal[i-1]!!
                if (totPointsVal[i]!=null)
                    require(pointMem<=totPointsVal[i]!!&& pointMem>=0){"illegal array points"}
            }
        }

    }

    val totPoints=totPointsVal


    fun addPoints(points:Int, week:Int){
        require(week in 1..52){"the week must be between 1 and 52"}
        var lastValidWeekPoints=0
        for (i in 0..<week-1){
            if (totPoints[i]!=null)
                lastValidWeekPoints=totPoints[i]!!
        }
        require(points>=lastValidWeekPoints){"illegal points"}
        totPoints[week-1]=points
    }

    fun timesZeroPointsScored():Int{
        var counter=0
        var lastScore=0
        for (i in totPoints.indices){
            val score=totPoints[i]
            if (score!=null){
                if (score==lastScore)
                    counter++
                lastScore=score
            }

        }
        return counter
    }

    fun returnWeekScore(week:Int):Int?{
        require(week in 1..52){"illegal requested week"}
        return totPoints[week-1]
    }

    fun weeksFor100Points():Int{
        var counter=0
        var pointCounter=0
        for (i in totPoints.indices){
            if (totPoints[i]!=null){
                counter++
                pointCounter+=totPoints[i]!!
                if (pointCounter>=100)
                    return counter
            }
        }
        return -1
    }

}