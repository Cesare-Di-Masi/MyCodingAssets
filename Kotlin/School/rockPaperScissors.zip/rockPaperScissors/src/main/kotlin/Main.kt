import kotlin.math.ceil

fun main(args: Array<String>) {

    val game=RockPaperScissors("Maurizio")
    println("you are going to play Rock Paper Scissors!")
    println("for choosing your rounds choose 1 (3 rounds) 2 (5 rounds) and 3 for your custom rounds")
    var gameTypeChoose: Int = readln().toInt()
    require(gameTypeChoose in 1..3){"Choose between 1,2,3"}
    var rounds:Int=0
    var playerWins:Int=0
    var classWins:Int=0
    when(gameTypeChoose){
        1 ->rounds=3
        2 ->rounds=5
        3 ->rounds= readln().toInt()
    }
    require(rounds>0){"the number of rounds must be a natural number and more than 0"}
    require(rounds%2==1){"the number of rounds must be an odd number"}


    do {
        println("For rock chose 1 for paper 2 for scissors 3")
        game.play(readln().toInt())
        when(game.winner){
            1 ->playerWins+=1
            2 ->classWins+=1
        }
        println(game)
    }while(((ceil(rounds.toDouble()) / 2) > playerWins) && ((ceil(rounds.toDouble()) / 2) > classWins))





}
