import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import java.lang.IllegalArgumentException


class TrafficLightTest {

    @Test
    fun hoursValueIsNotNatural() {
        assertThrows<IllegalArgumentException> { val trafficTest = TrafficLight(-10, 12, 3) }
    }

    @Test
    fun hoursValueIsMoreThan23() {
        assertThrows<IllegalArgumentException> { val trafficTest = TrafficLight(27, 12, 3) }
    }

    @Test
    fun hoursValueIsCorrect(){
        assertDoesNotThrow { val trafficTest = TrafficLight(10, 12, 3) }
    }

    @Test
    fun minutesValueIsNotNatural() {
        assertThrows<IllegalArgumentException> { val trafficTest = TrafficLight(10, -12, 3) }
    }

    @Test
    fun minutesValueIsMoreThan60() {
        assertThrows<IllegalArgumentException> { val trafficTest = TrafficLight(10, 80, 3) }
    }

    @Test
    fun minutesValueIsCorrect(){
        assertDoesNotThrow { val trafficTest = TrafficLight(10, 12, 3) }
    }

    @Test
    fun secondsValueIsNotNatural() {
        assertThrows<IllegalArgumentException> { val trafficTest = TrafficLight(10, 12, -3) }
    }

    @Test
    fun secondsValueIsMoreThan60() {
        assertThrows<IllegalArgumentException> { val trafficTest = TrafficLight(10, 12, 80) }
    }

    @Test
    fun secondsValueIsCorrect(){
        assertDoesNotThrow { val trafficTest = TrafficLight(10, 12, 3) }
    }

    @Test
    fun findTrafficLightsIsOffSoIsOrange(){
        val trafficTest = TrafficLight(23, 12, 3)
        trafficTest.findLight()
        assertEquals(TrafficLight.lightColour.Orange, trafficTest.trafficLight)
    }

    @Test
    fun findTrafficLightIsGreen(){
        val trafficTest = TrafficLight(4, 0, 0)
        trafficTest.findLight()
        assertEquals(TrafficLight.lightColour.Green, trafficTest.trafficLight)
    }

    @Test
    fun findTrafficLightIsOrange(){
        val trafficTest = TrafficLight(4, 1, 0)
        trafficTest.findLight()
        assertEquals(TrafficLight.lightColour.Orange, trafficTest.trafficLight)
    }

    @Test
    fun findTrafficLightIsRed(){
        val trafficTest = TrafficLight(4, 1, 30)
        trafficTest.findLight()
        assertEquals(TrafficLight.lightColour.Red, trafficTest.trafficLight)
    }

}