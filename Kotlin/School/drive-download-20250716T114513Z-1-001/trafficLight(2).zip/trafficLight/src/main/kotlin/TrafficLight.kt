class TrafficLight(hoursValue:Int,minutesValue:Int,secondsValue:Int) {

    private val GREENTIME=60
    private val ORANGETIME=30
    private val REDTIME=60
    private val TOTPERIODLIGHTS=GREENTIME+ORANGETIME+REDTIME
    private val TIMESHUTTINGDOWN=22
    private val TIMEPOWERON=3

    init {
        require(hoursValue in 0..23){"hours must be between 0 and 23"}
        require(minutesValue in 0..59){"minutes must be between 0 and 59"}
        require(secondsValue in 0..59){"seconds must be between 0 and 59"}
    }
    private val hours=hoursValue
    private val minutes=minutesValue
    private val seconds=secondsValue
    var trafficLight=lightColour.NoLight

    enum class lightColour{
        Red,Orange,Green,NoLight
    }
    private val period=hours*3600+minutes*60+seconds

    fun findLight(){

        trafficLight = when{
            hours >= TIMESHUTTINGDOWN || hours <= TIMEPOWERON-> lightColour.Orange
            period%TOTPERIODLIGHTS<GREENTIME-> lightColour.Green
            period%TOTPERIODLIGHTS<GREENTIME+ORANGETIME-> lightColour.Orange
            else-> lightColour.Red
        }

    }

}