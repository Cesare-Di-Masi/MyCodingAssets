import kotlin.random.Random


class EnergyRate(private val moneyKWhVal: Double) {

    init {
        require(moneyKWhVal >= 0) { "Illegal rate" }
    }

    fun totalCost(meter:EnergyMeter): Double {
        val totKWh = meter.totConsumeKWh()
        return moneyKWhVal * totKWh
    }

    fun changeRate(newRate: Double, startingMonth: Int, meter:EnergyMeter): Double {
        require(newRate >= 0) { "Illegal rate" }
        require(startingMonth in 1..12) { "Illegal month" }

        var totPreviousRate = 0.0
        var totNewRate = 0.0

        var last = 0
        for (i in 0..<startingMonth) {
            totPreviousRate += meter.kWhCounter[i]!! - last
            last = meter.kWhCounter[i]!!
        }
        totPreviousRate *= moneyKWhVal

        last = 0
        for (i in startingMonth..11) {
            totNewRate += meter.kWhCounter[i]!! - last
            last = meter.kWhCounter[i]!!
        }
        totNewRate *= newRate

        return totPreviousRate + totNewRate
    }

    fun makeRandomEnergyMeter(withoutNull:Boolean):EnergyMeter{
        val newMeterArray=Array<Int?>(12){null}
        var minNumber=0
        var number= 0
        for (i in newMeterArray.indices){

            if (withoutNull){
                number=Random.nextInt(minNumber, 1001)
                newMeterArray[i]=number
                minNumber=number
            }else{
                number=Random.nextInt(0, 1001)
                if (number==minNumber)
                    newMeterArray[i]=null
                else
                    newMeterArray[i]=number
            }

        }
        val newMeter=EnergyMeter(newMeterArray)
        return newMeter
    }

    fun giveListOfConsume(meter:EnergyMeter):String{

        var list="meterList:"
        for (i in meter.kWhCounter.indices){
            list+=meter.kWhCounter[i]
            list+=", "
        }
        return list
    }

    fun whatMeterConsumedMore(meter1:EnergyMeter, meter2:EnergyMeter):Int{

        return if (meter1.totConsumeKWh()>=meter2.totConsumeKWh())
            1
        else
            2
    }

}