class EnergyMeter(kWhCounterVal: Array<Int?>) {
    val MIN_MONTH=1
    val MAX_MONTH=12

    enum class Quarter { First, Second, Third, Fourth }

    init {
        require(kWhCounterVal.size == MAX_MONTH) { "The electricity counter size is illegal" }

        var lastCount = 0
        for (i in kWhCounterVal.indices) {
            if (kWhCounterVal[i] != null) {
                require(lastCount <= kWhCounterVal[i]!!) { "Illegal counter" }
                lastCount = kWhCounterVal[i]!!
            } else
                kWhCounterVal[i] = lastCount
        }
    }

    val kWhCounter = kWhCounterVal

    fun addMonthlyCount(count: Int, month: Int) {
        require(month in MIN_MONTH..MAX_MONTH) { "Month does not exist" }
        require(count >= 0) { "Count to add is illegal" }

        var lastCount = 0
        for (i in 0..<month - 1) {
            if (kWhCounter[i] != null)
                lastCount = kWhCounter[i]!!
        }

        if (count >= lastCount)
            kWhCounter[month - 1] = count
    }

    fun giveMonthCount(month: Int): Int {
        require(month in MIN_MONTH..MAX_MONTH) { "Month does not exist" }
        return kWhCounter[month - 1]!!
    }

    fun giveQuarterCount(quarter: Quarter): Int {
        val range = when (quarter) {
            Quarter.First -> 0..2
            Quarter.Second -> 3..5
            Quarter.Third -> 6..8
            Quarter.Fourth -> 9..11
        }

        var total = 0
        var last = 0
        for (i in range) {
            if (last != kWhCounter[i]) {
                total += kWhCounter[i]!! - last
                last = kWhCounter[i]!!
            }
        }
        return total
    }

    fun totConsumeKWh(): Int {
        var total = 0
        var last = 0
        for (i in kWhCounter.indices) {
            if (last != kWhCounter[i]) {
                total += kWhCounter[i]!! - last
                last = kWhCounter[i]!!
            }
        }
        return total
    }

    fun giveHighestConsumeMonth(): Int {
        var month = 0
        var maxConsume = 0
        var last = 0
        for (i in kWhCounter.indices) {
            val diff = kWhCounter[i]!! - last
            if (diff > maxConsume) {
                maxConsume = diff
                month = i
            }
            last = kWhCounter[i]!!
        }
        return month + 1
    }

    fun is0ConsumeMonth(month: Int): Boolean {
        require(month in MIN_MONTH..MAX_MONTH) { "Month does not exist" }
        val currentConsume = giveMonthCount(month)
        var lastCount = 0
        for (i in 0..<month - 1) {
            if (kWhCounter[i] != null)
                lastCount = kWhCounter[i]!!
        }
        return lastCount == currentConsume
    }

    fun listOfMonthsBiggerThanANumber(count:Int):Array<Int?>{
        require(count>=0){"count to check is Illegal"}
        val list=Array<Int?>(MAX_MONTH){null}
        var monthC=0

        for (i in kWhCounter.indices){
            if (kWhCounter[i]!!>count) {
                list[monthC] = i + 1
                monthC++
            }
        }
        return list
    }


}