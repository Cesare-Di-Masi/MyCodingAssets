fun main() {

    val testRate=EnergyRate(1.0)
    val meterArrayTest1=testRate.makeRandomEnergyMeter(true)
    println(testRate.giveListOfConsume(meterArrayTest1))
    val meterArrayTest2=testRate.makeRandomEnergyMeter(true)
    println(testRate.giveListOfConsume(meterArrayTest2))
    println(testRate.whatMeterConsumedMore(meterArrayTest1,meterArrayTest2))
    println(testRate.totalCost(meterArrayTest1))
    println(testRate.totalCost(meterArrayTest2))
    println(meterArrayTest1.totConsumeKWh())
    println(meterArrayTest2.totConsumeKWh())



}