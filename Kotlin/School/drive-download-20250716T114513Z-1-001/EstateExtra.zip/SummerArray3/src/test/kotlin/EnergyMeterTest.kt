import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*


class EnergyMeterTest(){

    @Test
    fun get_kWhCounterVal_Size_Is_Illegal_Smaller(){
        val testArray=Array<Int?>(11){null}
        assertThrows<IllegalArgumentException> { val test=EnergyMeter(testArray) }
    }

    @Test
    fun get_kWhCounterVal_Size_Is_Illegal_OutOfBounds(){
        val testArray=Array<Int?>(13){null}
        assertThrows<IllegalArgumentException> { val test=EnergyMeter(testArray) }
    }

    @Test
    fun get_kWhCounterVal_Count_Is_Illegal_Full() {
        val testArray = Array<Int?>(12) { 2 }
        testArray[1] = 1
        assertThrows<IllegalArgumentException> { val test = EnergyMeter(testArray) }
    }

    @Test
    fun get_kWhCounterVal_Count_Is_Illegal_WithNull() {
        val testArray = Array<Int?>(12) { null }
        testArray[11] = 1
        testArray[1] = 2
        assertThrows<IllegalArgumentException> { val test = EnergyMeter(testArray) }
    }

    @Test
    fun get_kWhCounterVal_Size_Is_legal(){
        val testArray=Array<Int?>(12){null}
        assertDoesNotThrow { val test=EnergyMeter(testArray) }
    }

    @Test
    fun get_kWhCounterVal_Count_Is_legal(){
        val testArray=Array<Int?>(12){1}
        assertDoesNotThrow { val test=EnergyMeter(testArray) }
    }

    @Test
    fun get_kWhCounterVal_Count_Null_Is_0(){
        val testArray=Array<Int?>(12){1}
        testArray[0] = null
        val test=EnergyMeter(testArray)
        assertEquals(0, test.kWhCounter[0])
    }

    @Test
    fun addMonthlyCount_month_Is_Illegal_Negative(){
        val testArray=Array<Int?>(12){null}
        val test=EnergyMeter(testArray)
        assertThrows<IllegalArgumentException> { test.addMonthlyCount(1,-1) }
    }

    @Test
    fun addMonthlyCount_month_Is_Illegal_OutOfBounds(){
        val testArray=Array<Int?>(12){null}
        val test=EnergyMeter(testArray)
        assertThrows<IllegalArgumentException> { test.addMonthlyCount(1,13) }
    }

    @Test
    fun addMonthlyCount_count_Is_Illegal_Negative(){
        val testArray=Array<Int?>(12){null}
        val test=EnergyMeter(testArray)
        assertThrows<IllegalArgumentException> { test.addMonthlyCount(-1,1) }
    }

    @Test
    fun addMonthlyCount_month_Is_legal(){
        val testArray=Array<Int?>(12){null}
        val test=EnergyMeter(testArray)
        assertDoesNotThrow { test.addMonthlyCount(1,12) }
    }

    @Test
    fun addMonthlyCount_count_Is_legal(){
        val testArray=Array<Int?>(12){null}
        val test=EnergyMeter(testArray)
        assertDoesNotThrow { test.addMonthlyCount(1,12) }
    }

    @Test
    fun addMonthlyCount_Is_Correct_Added(){
        val testArray=Array<Int?>(12){null}
        val test=EnergyMeter(testArray)
        test.addMonthlyCount(1,12)
        assertEquals(1,test.kWhCounter[11])
    }

    @Test
    fun addMonthlyCount_Is_Correct_NotAdded(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        test.addMonthlyCount(1,12)
        assertEquals(2,test.kWhCounter[11])
    }

    @Test
    fun giveMonthCount_month_Is_Illegal_Negative(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertThrows<IllegalArgumentException> { test.giveMonthCount(-1) }
    }

    @Test
    fun giveMonthCount_month_Is_Illegal_OutOfBounds(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertThrows<IllegalArgumentException> { test.giveMonthCount(13) }
    }

    @Test
    fun giveMonthCount_month_Is_legal(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertDoesNotThrow { test.giveMonthCount(12) }
    }

    @Test
    fun giveMonthCount_Is_Correct(){
        val testArray=Array<Int?>(12){null}
        testArray[1]=1
        val test=EnergyMeter(testArray)
        assertEquals(1,test.giveMonthCount(2))
    }

    @Test
    fun giveMonthCount_Is_Correct_NullMonth(){
        val testArray=Array<Int?>(12){2}
        testArray[1]=null
        val test=EnergyMeter(testArray)
        assertEquals(2,test.giveMonthCount(2))
    }

    @Test
    fun giveQuarterCount_Is_Correct_First(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertEquals(2,test.giveQuarterCount(EnergyMeter.Quarter.First))
    }

    @Test
    fun giveQuarterCount_Is_Correct_Second(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertEquals(2,test.giveQuarterCount(EnergyMeter.Quarter.Second))
    }

    @Test
    fun giveQuarterCount_Is_Correct_Third(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertEquals(2,test.giveQuarterCount(EnergyMeter.Quarter.Third))
    }

    @Test
    fun giveQuarterCount_Is_Correct_Fourth(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertEquals(2,test.giveQuarterCount(EnergyMeter.Quarter.Fourth))
    }

    @Test
    fun totConsumeKWh_Is_Correct(){
        val testArray=Array<Int?>(12){null}
        testArray[0]=1
        testArray[1]=3
        testArray[2]=6
        testArray[3]=7
        val test=EnergyMeter(testArray)
        assertEquals(7,test.totConsumeKWh())
    }

    @Test
    fun totConsumeKWh_Is_Correct_0(){
        val testArray=Array<Int?>(12){null}
        val test=EnergyMeter(testArray)
        assertEquals(0,test.totConsumeKWh())
    }

    @Test
    fun giveHighestConsumeMonth_Is_Correct(){
        val testArray=Array<Int?>(12){null}
        testArray[0]=1
        testArray[1]=2
        testArray[2]=2
        testArray[3]=6
        val test=EnergyMeter(testArray)
        assertEquals(4,test.giveHighestConsumeMonth())
    }

    @Test
    fun giveHighestConsumeMonth_Is_Correct_SameNumberMultipleTimes(){
        val testArray=Array<Int?>(12){null}
        testArray[0]=2
        testArray[1]=2
        testArray[2]=2
        testArray[3]=2
        val test=EnergyMeter(testArray)
        assertEquals(1,test.giveHighestConsumeMonth())
    }

    @Test
    fun give0ConsumeMonth_month_Is_Illegal_Negative(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertThrows<IllegalArgumentException> { test.is0ConsumeMonth(-1) }
    }

    @Test
    fun give0ConsumeMonth_month_Is_Illegal_OutOfBounds(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertThrows<IllegalArgumentException> { test.is0ConsumeMonth(13) }
    }

    @Test
    fun give0ConsumeMonth_month_Is_legal(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertDoesNotThrow { test.is0ConsumeMonth(12) }
    }

    @Test
    fun give0ConsumeMonth_month_Is_Correct_True(){
        val testArray=Array<Int?>(12){null}
        testArray[0]=2
        testArray[1]=2
        val test=EnergyMeter(testArray)
        assertEquals(true,test.is0ConsumeMonth(2))
    }

    @Test
    fun give0ConsumeMonth_month_Is_Correct_False(){
        val testArray=Array<Int?>(12){null}
        testArray[0]=2
        testArray[1]=3
        val test=EnergyMeter(testArray)
        assertEquals(false,test.is0ConsumeMonth(2))
    }

    @Test
    fun listOfMonthsBiggerThanANumber_count_Is_Illegal_Negative(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertThrows<IllegalArgumentException> { test.listOfMonthsBiggerThanANumber(-1) }
    }

    @Test
    fun listOfMonthsBiggerThanANumber_count_Is_legal(){
        val testArray=Array<Int?>(12){2}
        val test=EnergyMeter(testArray)
        assertDoesNotThrow { test.listOfMonthsBiggerThanANumber(1) }
    }

    @Test
    fun listOfMonthsBiggerThanANumber_Is_Correct(){
        val testArray=Array<Int?>(12){null}
        testArray[0]=2
        testArray[1]=2
        testArray[2]=3
        testArray[3]=3
        testArray[10]=4
        testArray[11]=5
        val arrayCheck=Array<Int?>(12){null}
        arrayCheck[0]=11
        arrayCheck[1]=12
        val test=EnergyMeter(testArray)
        assertArrayEquals(arrayCheck,test.listOfMonthsBiggerThanANumber(3))
    }

    @Test
    fun listOfMonthsBiggerThanANumber_Is_Correct_0(){
        val testArray=Array<Int?>(12){2}
        val arrayCheck=Array<Int?>(12){null}
        val test=EnergyMeter(testArray)
        assertArrayEquals(arrayCheck,test.listOfMonthsBiggerThanANumber(3))
    }

}