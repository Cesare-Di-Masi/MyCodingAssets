import org.junit.jupiter.api.*

import org.junit.jupiter.api.Assertions.*

class SongTest {

    @Test
    fun getSongNameValue_Is_Illegal_Blank(){
        assertThrows<IllegalArgumentException> { val songTest=Song(" ","John",120) }
    }

    @Test
    fun getSongNameValue_Is_Illegal_Empty(){
        assertThrows<IllegalArgumentException> { val songTest=Song("","John",120) }
    }

    @Test
    fun getSongNameValue_Is_Legal(){
        assertDoesNotThrow { val songTest=Song("john is singing","John",120) }
    }

    @Test
    fun getSingerValue_Is_Illegal_Blank(){
        assertThrows<IllegalArgumentException> { val songTest=Song("john is singing","",120) }
    }

    @Test
    fun getSingerValue_Is_Illegal_Empty(){
        assertThrows<IllegalArgumentException> { val songTest=Song("john is singing"," ",120) }
    }

    @Test
    fun getSingerValue_Is_Legal(){
        assertDoesNotThrow { val songTest=Song("john is singing","John",120) }
    }

    @Test
    fun getDurationSecValue_Is_Illegal_Negative(){
        assertThrows<IllegalArgumentException> { val songTest=Song("john is singing","John",-1) }
    }

    @Test
    fun getDurationSecValue_Is_Illegal_0(){
        assertThrows<IllegalArgumentException> { val songTest=Song("john is singing","John",0) }
    }

    @Test
    fun getDurationSecValue_Is_Legal(){
        assertDoesNotThrow { val songTest=Song("john is singing","John",120) }
    }

}