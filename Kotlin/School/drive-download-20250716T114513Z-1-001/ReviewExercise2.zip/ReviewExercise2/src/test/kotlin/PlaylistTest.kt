import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

class PlaylistTest {

    fun initializeArray():Array<Song> {
        val song1 = Song("t1", "s1", 100)
        val song2 = Song("t2", "s1", 120)
        val song3 = Song("t3", "s2", 133)
        val songs = Array<Song>(3) { song1 }
        songs[1]=song2
        songs[2]=song3
        return songs
    }

    @Test
    fun getDuration_Is_Correct() {
        val array=initializeArray()
        val playlist=Playlist(array)
        assertEquals(353,playlist.duration)
    }

    @Test
    fun numberOfSongsOfASinger() {
        val array=initializeArray()
        val playlist=Playlist(array)
        assertEquals(3,playlist.numberOfSongs)
    }

    @Test
    fun getSongs() {
        val array=initializeArray()
        val playlist=Playlist(array)
        assertEquals(2,playlist.numberOfSongsOfASinger("s1"))
    }
}