class Playlist(val songs:Array<Song>) {
    val duration:Int
        get() {
            var totalSec=0
            for(i in songs)
                totalSec+=i.durationSec
            return totalSec
        }
    val numberOfSongs:Int
        get() {
            return songs.size
        }

    fun numberOfSongsOfASinger(singer:String):Int{
        require(singer.isNotBlank()&&singer.isNotEmpty()){"illegal requested singer"}
        var counter=0
        for (i in songs){
            if (i.singer==singer)
                counter++
        }
        return counter
    }

}