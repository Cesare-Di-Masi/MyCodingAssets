class Song(songNameValue:String, singerValue:String, durationSecValue:Int) {

    init {
        require(songNameValue.isNotBlank()&&songNameValue.isNotEmpty()){"illegal songNameValue init"}
        require(singerValue.isNotEmpty()&&singerValue.isNotBlank()){"illegal singerValue init"}
        require(durationSecValue>0){"illegal durationSecValue init"}
    }

    val songName=songNameValue
    val singer=singerValue
    val durationSec=durationSecValue

}