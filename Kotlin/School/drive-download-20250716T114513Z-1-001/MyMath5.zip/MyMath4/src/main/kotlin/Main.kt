fun main(args: Array<String>) {

    val n=MyMath5()
    println(n.calculateMCD(13,17))
    println(n.coprimi(78,14))
    println(n.amicabili(220,284))
    println(n.calculateFibonacciSuccession(10))
    println(n.calculateTribonacciSuccession(10))
    println(n.calculatemcm(10,50))
    println(n.calulateFactorial(6))
    println(n.calculateTime(12,3))
    println(n.calculateDistance(12,3))
    println(n.sumFibonacci(2,6))
    println(n.binToDec(101))
    println(n.isNumberPalindrome(103))
    println(n.isNumberTriangular(3,6))

}