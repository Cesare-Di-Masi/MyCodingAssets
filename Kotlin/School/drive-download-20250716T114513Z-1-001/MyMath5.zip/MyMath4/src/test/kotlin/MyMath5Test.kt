import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import kotlin.IllegalArgumentException


class MyMath5Test(){

    @Test
    fun coprimiNumber1IsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.coprimi(-1,1) }
    }

    @Test
    fun coprimiNumber1IsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.coprimi(1,1) }
    }

    @Test
    fun coprimiNumber2IsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.coprimi(1,-11) }
    }

    @Test
    fun coprimiNumber2IsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.coprimi(1,1) }
    }

    @Test
    fun coprimiIsCorrect(){
        val myMayhTest=MyMath5()
        assertEquals(true, myMayhTest.coprimi(1,1))
    }

    @Test
    fun MCDnumber1IsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculateMCD(-1,1) }
    }

    @Test
    fun MCDNumber1IsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calculateMCD(1,1) }
    }

    @Test
    fun MCDnumber2IsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculateMCD(1,-11) }
    }

    @Test
    fun MCDNumber2IsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calculateMCD(1,1) }
    }

    @Test
    fun MCDIsCorrect(){
        val myMayhTest=MyMath5()
        assertEquals(13, myMayhTest.calculateMCD(26,13))
    }

    @Test
    fun mcmNumber1IsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculatemcm(-1,1) }
    }

    @Test
    fun mcmNumber1IsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calculatemcm(1,1) }
    }

    @Test
    fun mcmNumber2IsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculatemcm(1,-11) }
    }

    @Test
    fun mcmNumber2IsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calculatemcm(1,1) }
    }

    @Test
    fun mcmIsCorrect(){
        val myMayhTest=MyMath5()
        assertEquals(26, myMayhTest.calculatemcm(26,13))
    }


    @Test
    fun amicabiliNumber1IsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.amicabili(-1,1) }
    }

    @Test
    fun amicabiliNumber1IsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.amicabili(1,1) }
    }

    @Test
    fun amicabiliNumber2IsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.amicabili(1,-11) }
    }

    @Test
    fun amicabiliNumber2IsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.amicabili(1,1) }
    }

    @Test
    fun amicabiliIsCorrect(){
        val myMayhTest=MyMath5()
        assertEquals(true, myMayhTest.amicabili(220,284))
    }

    @Test
    fun FibonacciNumberIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculateFibonacciSuccession(-16) }
    }

    @Test
    fun FibonacciNumberIs0(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException>{ myMathTest.calculateFibonacciSuccession(0) }
    }

    @Test
    fun FibonacciNumberIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calculateFibonacciSuccession(10) }
    }

    @Test
    fun FibonacciIsCorrect(){
        val myMayhTest=MyMath5()
        assertEquals(34, myMayhTest.calculateFibonacciSuccession(10))
    }

    @Test
    fun TribonacciNumberIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculateTribonacciSuccession(-16) }
    }

    @Test
    fun TribonacciNumberIs0(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculateTribonacciSuccession(0) }
    }

    @Test
    fun TribonacciNumberIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calculateTribonacciSuccession(10) }
    }

    @Test
    fun TribonacciIsCorrect(){
        val myMayhTest=MyMath5()
        assertEquals(81, myMayhTest.calculateTribonacciSuccession(10))
    }

    @Test
    fun factorialNumberIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calulateFactorial(-11) }
    }

    @Test
    fun factorialNumberIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calulateFactorial(10) }
    }

    @Test
    fun factorialIsCorrect(){
        val myMayhTest=MyMath5()
        assertEquals(6, myMayhTest.calulateFactorial(3))
    }

    @Test
    fun calculateTimeDistanceIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculateTime(-12,3) }
    }

    @Test
    fun calculateTimeDistanceIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calculateTime(12,3) }
    }

    @Test
    fun calculateTimeVelocityIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculateTime(12,-3) }
    }

    @Test
    fun calculateTimeVelocityIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calculateTime(12,3) }
    }

    @Test
    fun calculateTimeIsCorrect(){
        val myMayhTest=MyMath5()
        assertEquals(36, myMayhTest.calculateTime(12,3))
    }

    @Test
    fun calculateDistanceTimeIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculateDistance(-12,3) }
    }

    @Test
    fun calculateDistanceTimeIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calculateDistance(12,3) }
    }

    @Test
    fun calculateDistanceVelocityIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.calculateDistance(12,-3) }
    }

    @Test
    fun calculateDistanceVelocityIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.calculateDistance(12,3) }
    }

    @Test
    fun calculateDistanceIsCorrect(){
        val myMayhTest=MyMath5()
        assertEquals(4, myMayhTest.calculateDistance(12,3))
    }

    @Test
    fun binToDecNumberIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.binToDec(-1) }
    }

    @Test
    fun binToDecNumberIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.binToDec(101) }
    }

    @Test
    fun binToDecIsCorrect(){
        val myMayhTest=MyMath5()
        assertEquals(5, myMayhTest.binToDec(101))
    }

    @Test
    fun isPalindromeNumberIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.isNumberPalindrome(-101) }
    }

    @Test
    fun isPalindromeNumberIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.isNumberPalindrome(101) }
    }

    @Test
    fun isPalindromeIsCorrectTrue(){
        val myMayhTest=MyMath5()
        assertEquals(true, myMayhTest.isNumberPalindrome(101))
    }

    @Test
    fun isPalindromeIsCorrectFalse(){
        val myMayhTest=MyMath5()
        assertEquals(false, myMayhTest.isNumberPalindrome(103))
    }

    @Test
    fun isTriangularNumberIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.isNumberTriangular(-3,4) }
    }

    @Test
    fun isTriangularNumberIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.isNumberTriangular(3,4) }
    }

    @Test
    fun isTriangularTriangularNumberIsNotNatural(){
        val myMathTest=MyMath5()
        assertThrows<IllegalArgumentException> { myMathTest.isNumberTriangular(3,-4) }
    }

    @Test
    fun isTriangularTriangularNumberIsCorrect(){
        val myMathTest=MyMath5()
        assertDoesNotThrow { myMathTest.isNumberTriangular(3,4) }
    }

    @Test
    fun isTriangularIsCorrectTrue(){
        val myMayhTest=MyMath5()
        assertEquals(true, myMayhTest.isNumberTriangular(3,6))
    }

    @Test
    fun isTriangularIsCorrectFalse(){
        val myMayhTest=MyMath5()
        assertEquals(false, myMayhTest.isNumberTriangular(3,4))
    }

}