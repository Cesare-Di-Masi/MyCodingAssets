class Person(nameVal:String, surnameVal:String, dayVal:Int,monthVal:Int, yearVal:Int) {
    private val MIN_YEAR=2000
    private val MAX_YEAR=2024

    init {
        require(nameVal.isNotEmpty()&&nameVal.isNotBlank()){"illegal nameVal"}
        require(surnameVal.isNotEmpty()&&surnameVal.isNotBlank()){"illegal surnameVal"}
        require(monthVal in 1..12){"illegal monthVal"}
        require(yearVal in MIN_YEAR..MAX_YEAR )
        when{
            monthVal==1||monthVal==3||monthVal==5||monthVal==7||monthVal==8||monthVal==10||monthVal==12-> require(dayVal in 1..31)
            monthVal==2&&yearVal%4==0-> require(dayVal in 1..29)
            monthVal==2-> require(dayVal in 1..28)
            else-> require(dayVal in 1..30)
        }
    }

    val name=nameVal
    val surname=surnameVal
    val day=dayVal
    val month=monthVal
    val year=yearVal

    fun calculateAge(thisDay:Int,thisMonth:Int,thisYear:Int):Int{

        require(thisMonth in 1..12){"illegal monthVal"}
        require(thisYear in year..MAX_YEAR )
        when{
            thisMonth==1||thisMonth==3||thisMonth==5||thisMonth==7||thisMonth==8||thisMonth==10||thisMonth==12-> require(thisDay in 1..31)
            thisMonth==2&&thisYear%4==0-> require(thisDay in 1..29)
            thisMonth==2-> require(thisDay in 1..28)
            else-> require(thisDay in 1..30)
        }

        return (thisYear-year)*3600+(thisMonth-month)*60+(thisDay-day)
    }

    fun comparisonAge(thisDay:Int,thisMonth:Int,thisYear:Int,guy:Person):Int{
        return when{
            calculateAge(thisDay,thisMonth,thisYear)==guy.calculateAge(thisDay,thisMonth,thisYear)-> 0
            calculateAge(thisDay,thisMonth,thisYear)<=guy.calculateAge(thisDay,thisMonth,thisYear)-> 1
            else-> -1
        }
    }

}