import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.*

class PersonTest {

    @Test
    fun name_Is_Illegal_Empty() {
        assertThrows<IllegalArgumentException> { Person("", "Doe", 1, 1, 2000) }
    }

    @Test
    fun name_Is_Illegal_Blank() {
        assertThrows<IllegalArgumentException> { Person(" ", "Doe", 1, 1, 2000) }
    }

    @Test
    fun surname_Is_Illegal_Empty() {
        assertThrows<IllegalArgumentException> { Person("John", "", 1, 1, 2000) }
    }

    @Test
    fun surname_Is_Illegal_Blank() {
        assertThrows<IllegalArgumentException> { Person("John", " ", 1, 1, 2000) }
    }

    @Test
    fun month_Is_Illegal() {
        assertThrows<IllegalArgumentException> { Person("John", "Doe", 1, 13, 2000) }
    }

    @Test
    fun year_Is_Illegal_Before_Min() {
        assertThrows<IllegalArgumentException> { Person("John", "Doe", 1, 1, 1999) }
    }

    @Test
    fun year_Is_Illegal_After_Max() {
        assertThrows<IllegalArgumentException> { Person("John", "Doe", 1, 1, 2025) }
    }

    @Test
    fun day_Is_Illegal_February_Non_Leap_Year() {
        assertThrows<IllegalArgumentException> { Person("John", "Doe", 29, 2, 2001) }
    }

    @Test
    fun day_Is_Illegal_February_Leap_Year() {
        assertThrows<IllegalArgumentException> { Person("John", "Doe", 30, 2, 2000) }
    }

    @Test
    fun day_Is_Illegal_30_Day_Month() {
        assertThrows<IllegalArgumentException> { Person("John", "Doe", 31, 4, 2000) }
    }

    @Test
    fun person_Creation_Is_Legal() {
        assertDoesNotThrow { Person("John", "Doe", 15, 7, 2010) }
    }

    @Test
    fun calculateAge_Is_Correct_Same_Month_And_Day() {
        val person = Person("John", "Doe", 15, 7, 2010)
        assertEquals(14 * 3600, person.calculateAge(15, 7, 2024)) // 14 years in days
    }

    @Test
    fun calculateAge_Is_Correct_Different_Month() {
        val person = Person("John", "Doe", 15, 7, 2010)
        assertEquals(14 * 3600 + 5 * 60, person.calculateAge(15, 12, 2024)) // 14 years, 5 months
    }

    @Test
    fun calculateAge_Is_Illegal_Month() {
        val person = Person("John", "Doe", 15, 7, 2010)
        assertThrows<IllegalArgumentException> { person.calculateAge(15, 13, 2024) }
    }

    @Test
    fun comparisonAge_Is_Correct_Younger() {
        val person1 = Person("John", "Doe", 15, 7, 2010)
        val person2 = Person("Jane", "Doe", 20, 10, 2012)
        assertEquals(1, person1.comparisonAge(15, 7, 2024, person2))
    }

    @Test
    fun comparisonAge_Is_Correct_Older() {
        val person1 = Person("John", "Doe", 15, 7, 2010)
        val person2 = Person("Jane", "Doe", 20, 10, 2008)
        assertEquals(-1, person1.comparisonAge(15, 7, 2024, person2))
    }

    @Test
    fun comparisonAge_Is_Correct_Same_Age() {
        val person1 = Person("John", "Doe", 15, 7, 2010)
        val person2 = Person("Jane", "Doe", 15, 7, 2010)
        assertEquals(0, person1.comparisonAge(15, 7, 2024, person2))
    }
}