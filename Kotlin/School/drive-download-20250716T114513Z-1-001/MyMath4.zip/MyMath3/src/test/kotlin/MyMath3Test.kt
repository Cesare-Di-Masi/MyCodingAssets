import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import kotlin.IllegalArgumentException


class MyMath3Test(){

    @Test
    fun coprimiNumber1IsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.coprimi(-1,1) }
    }

    @Test
    fun coprimiNumber1IsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.coprimi(1,1) }
    }

    @Test
    fun coprimiNumber2IsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.coprimi(1,-11) }
    }

    @Test
    fun coprimiNumber2IsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.coprimi(1,1) }
    }

    @Test
    fun coprimiIsCorrect(){
        val myMayhTest=MyMath3()
        assertEquals(true, myMayhTest.coprimi(1,1))
    }

    @Test
    fun MCDnumber1IsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculateMCD(-1,1) }
    }

    @Test
    fun MCDNumber1IsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calculateMCD(1,1) }
    }

    @Test
    fun MCDnumber2IsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculateMCD(1,-11) }
    }

    @Test
    fun MCDNumber2IsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calculateMCD(1,1) }
    }

    @Test
    fun MCDIsCorrect(){
        val myMayhTest=MyMath3()
        assertEquals(13, myMayhTest.calculateMCD(26,13))
    }

    @Test
    fun mcmNumber1IsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculatemcm(-1,1) }
    }

    @Test
    fun mcmNumber1IsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calculatemcm(1,1) }
    }

    @Test
    fun mcmNumber2IsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculatemcm(1,-11) }
    }

    @Test
    fun mcmNumber2IsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calculatemcm(1,1) }
    }

    @Test
    fun mcmIsCorrect(){
        val myMayhTest=MyMath3()
        assertEquals(26, myMayhTest.calculatemcm(26,13))
    }


    @Test
    fun amicabiliNumber1IsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.amicabili(-1,1) }
    }

    @Test
    fun amicabiliNumber1IsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.amicabili(1,1) }
    }

    @Test
    fun amicabiliNumber2IsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.amicabili(1,-11) }
    }

    @Test
    fun amicabiliNumber2IsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.amicabili(1,1) }
    }

    @Test
    fun amicabiliIsCorrect(){
        val myMayhTest=MyMath3()
        assertEquals(true, myMayhTest.amicabili(220,284))
    }

    @Test
    fun FibonacciNumberIsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculateFibonacciSuccession(-16) }
    }

    @Test
    fun FibonacciNumberIs0(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException>{ myMathTest.calculateFibonacciSuccession(0) }
    }

    @Test
    fun FibonacciNumberIsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calculateFibonacciSuccession(10) }
    }

    @Test
    fun FibonacciIsCorrect(){
        val myMayhTest=MyMath3()
        assertEquals(34, myMayhTest.calculateFibonacciSuccession(10))
    }

    @Test
    fun TribonacciNumberIsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculateTribonacciSuccession(-16) }
    }

    @Test
    fun TribonacciNumberIs0(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculateTribonacciSuccession(0) }
    }

    @Test
    fun TribonacciNumberIsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calculateTribonacciSuccession(10) }
    }

    @Test
    fun TribonacciIsCorrect(){
        val myMayhTest=MyMath3()
        assertEquals(81, myMayhTest.calculateTribonacciSuccession(10))
    }

    @Test
    fun factorialNumberIsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calulateFactorial(-11) }
    }

    @Test
    fun factorialNumberIsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calulateFactorial(10) }
    }

    @Test
    fun factorialIsCorrect(){
        val myMayhTest=MyMath3()
        assertEquals(6, myMayhTest.calulateFactorial(3))
    }

    @Test
    fun calculateTimeDistanceIsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculateTime(-12,3) }
    }

    @Test
    fun calculateTimeDistanceIsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calculateTime(12,3) }
    }

    @Test
    fun calculateTimeVelocityIsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculateTime(12,-3) }
    }

    @Test
    fun calculateTimeVelocityIsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calculateTime(12,3) }
    }

    @Test
    fun calculateTimeIsCorrect(){
        val myMayhTest=MyMath3()
        assertEquals(36, myMayhTest.calculateTime(12,3))
    }

    @Test
    fun calculateDistanceTimeIsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculateDistance(-12,3) }
    }

    @Test
    fun calculateDistanceTimeIsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calculateDistance(12,3) }
    }

    @Test
    fun calculateDistanceVelocityIsNotNatural(){
        val myMathTest=MyMath3()
        assertThrows<IllegalArgumentException> { myMathTest.calculateDistance(12,-3) }
    }

    @Test
    fun calculateDistanceVelocityIsCorrect(){
        val myMathTest=MyMath3()
        assertDoesNotThrow { myMathTest.calculateDistance(12,3) }
    }

    @Test
    fun calculateDistanceIsCorrect(){
        val myMayhTest=MyMath3()
        assertEquals(4, myMayhTest.calculateDistance(12,3))
    }

}