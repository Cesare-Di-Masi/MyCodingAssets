fun main(args: Array<String>) {

    val sensore=TemperatureSensor(0.1)

    println(sensore.temperatureC)
    println(sensore.temperatureF)
    println(sensore.temperatureK)
}