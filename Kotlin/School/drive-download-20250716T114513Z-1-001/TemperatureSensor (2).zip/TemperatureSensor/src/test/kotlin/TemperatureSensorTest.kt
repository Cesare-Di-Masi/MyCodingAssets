import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*


class TemperatureSensorTest {

    @Test
    fun getCOSTANTE_CONVERSIONE_CELSIUS_KELVIN_MORE_THAN_273() {
        assertThrows<IllegalArgumentException>{ val sensorTest=TemperatureSensor(-273.5) }
    }

    @Test
    fun temperature_Farheneith(){
            }
}