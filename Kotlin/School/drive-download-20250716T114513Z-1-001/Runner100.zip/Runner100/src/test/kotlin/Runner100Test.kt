import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*


class Runner100Test(){

    @Test
    fun name_IsIllegal_Blank(){
        assertThrows<IllegalArgumentException> { val runnerTest=Runner100(" ") }
    }

    @Test
    fun name_IsIllegal_Empty(){
        assertThrows<IllegalArgumentException> { val runnerTest=Runner100("") }
    }

    @Test
    fun name_IsLegal(){
        assertDoesNotThrow { val runnerTest=Runner100("Jason") }
    }

    @Test
    fun addResults_newResult_IsIllegal_Negative(){

        val runnerTest=Runner100("Jason")
        assertThrows<IllegalArgumentException> { runnerTest.addResults(-1) }

    }

    @Test
    fun addResults_newResult_IsLegal(){
        val runnerTest=Runner100("Jason")
        assertDoesNotThrow { runnerTest.addResults(1) }

    }

    @Test
    fun addResults_IsCorrect_withSpaceLeft(){
        val runnerTest=Runner100("Jason")
        runnerTest.addResults(2000)
        assertEquals(2000,runnerTest.totalResults[0])
    }

    @Test
    fun addResults_IsCorrect_withoutSpaceLeft(){
        val runnerTest=Runner100("Jason")
        for (i in 1..8)
            runnerTest.addResults(2000)
        runnerTest.addResults(1000)
        runnerTest.addResults(2700)
        assertEquals(2700,runnerTest.totalResults[9])
    }

}