class Runner100(nameValue:String) {
    val totalResults:Array<Int>
    init {
        require(nameValue.isNotBlank()&&nameValue.isNotEmpty()){"name is illegal"}
        totalResults=Array<Int>(10){0}
    }
    private var worstResultPos=0


    fun addResults(newResult:Int){

        require(newResult>0){"newResult is illegal"}
        for (i in totalResults.indices){

            if (totalResults[i]==0)
                totalResults[i]=newResult
            else if (totalResults[9]!=0&&newResult>=findMinResult()){
                totalResults[worstResultPos]=newResult
            }

        }

    }

    fun findMaxResult(): Int {

        var max = totalResults[0]
        for(i in totalResults)
        {
            if(i > max)
                max = i
        }
        return max
    }

    fun findMinResult(): Int {
        var min = totalResults[0]
        for(i in totalResults.indices)
        {
            if(totalResults[i] < min&&totalResults[i]!=0){
                min = totalResults[i]
                worstResultPos=i}
        }
        return min
    }

}