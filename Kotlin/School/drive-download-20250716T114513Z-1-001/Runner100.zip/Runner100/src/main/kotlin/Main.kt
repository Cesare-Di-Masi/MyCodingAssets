fun main(args: Array<String>) {

    val runnerTest=Runner100("Jason")
    runnerTest.addResults(1000)
    println(runnerTest.totalResults[0])
    runnerTest.addResults(2700)
    println(runnerTest.totalResults[2])


}