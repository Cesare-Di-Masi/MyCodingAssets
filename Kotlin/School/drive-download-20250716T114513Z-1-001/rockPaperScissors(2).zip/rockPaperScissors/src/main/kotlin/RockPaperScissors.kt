class RockPaperScissors(nameValue:String) {

    init {
        require(nameValue.isNotBlank()&&nameValue.isNotEmpty()){"Digit a usable name for the player"}
    }


    val name= nameValue
    private var winner=EndRound.NOBODY
    private var roundsPlayed=0
    private var classMove:Int=0
    private var lastPlayerMove:Int=0
    var playerWins=0
    var classWins=0
    private var classMoveShow=Move.Rock
    private var playerMoveShow=Move.Rock

    private fun randomNumber(): Int {
        return (1..3).random()
    }
    fun chooseGameRounds(){
        println("you are going to play Rock Paper Scissors!")
        println("for choosing your rounds choose 1 (3 rounds) 2 (5 rounds) and 3 for your custom rounds")
        val gameTypeChoose: Int = readln().toInt()
        require(gameTypeChoose in 1..3){"Choose between 1,2,3"}
        var rounds:Int=0

        when(gameTypeChoose){
            1 ->rounds=3
            2 ->rounds=5
            3 ->rounds= readln().toInt()
        }
        require(rounds>0){"the number of rounds must be a natural number and more than 0"}
        require(rounds%2==1){"the number of rounds must be an odd number"}
    }

    fun play(playerMove:Int) {
        require(playerMove in 1..3){"the chosen move must be wrote with a number between 1 and 3 (rock,paper,scissors)"}
        classMove=randomNumber()
        lastPlayerMove=playerMove
        when(playerMove){
            1->playerMoveShow=Move.Rock
            2->playerMoveShow=Move.Paper
            3->playerMoveShow=Move.Scissors
        }
        when(classMove){
            1->classMoveShow=Move.Rock
            2->classMoveShow=Move.Paper
            3->classMoveShow=Move.Scissors
        }

        return if (playerMove==classMove){
            winner=EndRound.Tie
            roundsPlayed+=1
        }else{
            if (playerMove==classMove+1||(playerMove==1&&classMove==3)){
                winner=EndRound.Player
                roundsPlayed+=1
                playerWins+=1
            }else{
               winner=EndRound.Class
                roundsPlayed+=1
                classWins+=1
            }
        }


    }

    enum class Move{
        Rock,Paper,Scissors
    }
    enum class EndRound{
        Tie,Class,Player,NOBODY
    }

    override fun toString(): String {
        return when (winner) {
            EndRound.Tie -> "It's a tie!(class chose $classMove Player chose $lastPlayerMove). Score: P($playerWins) C($classWins)"
            EndRound.Player -> "the player wins!(class chose $classMove Player chose $lastPlayerMove). Score: P($playerWins) C($classWins)"
            EndRound.Class -> "the class wins!(class chose $classMove Player chose $lastPlayerMove. Score: P($playerWins) C($classWins))"
            else->"Nobody Won"
        }

    }

    }




