import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import java.lang.IllegalArgumentException


class MyMathTest {

    @Test
    fun nInt_Is_Zero() {
        assertThrows<IllegalArgumentException> { val myMathTest = MyMath(0) }
    }

    @Test
    fun nInt_Is_Correct(){
        assertDoesNotThrow { val myMathTest = MyMath(1)}
    }

    @Test
    fun nDivisor_Is_Correct(){
        val myMathTest = MyMath(12)
        myMathTest.findDividers()
        assertEquals(myMathTest.nDivisors,6)
    }

    @Test
    fun nDivisor_Is_Negative_And_Correct() {
        val myMathTest = MyMath(-12)
        myMathTest.findDividers()
        assertEquals(myMathTest.nDivisors, 6)
    }

    @Test
    fun nInt_Is_A_Prime_Number_And_nDivisor_Is_Correct() {
        val myMathTest = MyMath(1)
        myMathTest.findDividers()
        assertEquals(myMathTest.nDivisors, 1)
    }

}