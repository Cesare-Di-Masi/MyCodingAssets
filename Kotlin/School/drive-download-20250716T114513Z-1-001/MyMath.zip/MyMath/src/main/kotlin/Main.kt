fun main(args: Array<String>) {

    val N=MyMath(0)
    N.findDividers()
    println(N)

}