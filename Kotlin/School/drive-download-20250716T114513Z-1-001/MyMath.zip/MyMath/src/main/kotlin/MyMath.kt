import kotlin.math.abs

class MyMath(nIntValue:Int) {
    init {
        require(nIntValue!=0){"the number mustn't be 0"}
    }

    private val nInt=nIntValue
    var nDivisors=0
        private set

    fun findDividers(){
        for (i in 1..abs(nInt) step 1){
            if (nInt%i==0){
                nDivisors+=1
            }
        }
    }

    override fun toString(): String {
        if (nDivisors<=2){
            return "The number of divisors is 2 so the number is prime"
        }else{
            return "The number of divisors is $nDivisors"
        }
    }

}