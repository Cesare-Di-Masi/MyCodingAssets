class RockPaperScissors(nameValue:String) {

    init {
        require(nameValue.isNotBlank()&&nameValue.isNotEmpty()){"Digit a usable name for the player"}
    }

    val name= nameValue
    var winner:Int = 0
    private var roundsPlayed=0

    fun play(playerMove:Int) {
        require(playerMove in 1..3){"the chosen move must be wrote with a number between 1 and 3 (rock,paper,scissors)"}
        val classMove=randomNumber()

        return if (playerMove==classMove){
            winner=0
            roundsPlayed+=1
        }else{
            if (playerMove==classMove+1){
                winner=1
                roundsPlayed+=1
            }else{
               winner=2
                roundsPlayed+=1
            }
        }


    }

    fun randomNumber(): Int {
        return (1..3).random()
    }

    override fun toString(): String {
        return if (winner==0)
            "It's a tie!(class chose ${randomNumber()})"
        else{
            if (winner==1)
                "the player wins!(class chose ${randomNumber()})"
            else
                "the class wins!(class chose ${randomNumber()})"
        }
    }




}