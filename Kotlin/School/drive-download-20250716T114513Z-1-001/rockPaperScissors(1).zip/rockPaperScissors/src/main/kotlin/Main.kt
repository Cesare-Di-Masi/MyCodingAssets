import kotlin.math.ceil

fun main(args: Array<String>) {

    val game=RockPaperScissors("Maurizio")
    println("you are going to play Rock Paper Scissors!")
    println("for choosing your rounds choose 1 (3 rounds) 2 (5 rounds) and 3 for your custom rounds")
    var gameTypeChoose: Int = readln().toInt()
    require(gameTypeChoose in 1..3){"Choose between 1,2,3"}
    var rounds:Int=0
    when(gameTypeChoose){
        1 ->rounds=3
        2 ->rounds=5
        3 ->rounds= readln().toInt()
    }


    do {
        var playerWins:Int=0
        var classWins:Int=0
        println("For rock chose 1 for paper 2 for scissors 3")
        game.play(readln().toInt())
        println(game)
        when(game.winner){
            1 ->playerWins+=1
            2 ->classWins+=1
        }
    }while(((ceil(rounds.toDouble()) / 2) > playerWins) && ((ceil(rounds.toDouble()) / 2) > classWins))





}
