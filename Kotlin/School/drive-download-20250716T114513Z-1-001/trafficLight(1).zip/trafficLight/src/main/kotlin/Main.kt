fun main(args: Array<String>) {

    val test=TrafficLight(10,25,10)
    test.findLight()
    println(test.trafficLight)

}