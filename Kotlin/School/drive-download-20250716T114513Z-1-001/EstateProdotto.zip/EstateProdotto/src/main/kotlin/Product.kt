class Product(codeVal:String,descriptionVal:String,priceVal:Double) {

    init {
        require(codeVal.isNotEmpty()&&codeVal.isNotBlank()){"codeval Is Illegal"}
        require(descriptionVal.isNotEmpty()&&descriptionVal.isNotBlank()){"descriptionVal is Illegal"}
        require(priceVal>0.0){"priceVal is Illegal"}
    }

    val price=priceVal

    fun findSalePrice(percent:Double):Double{
        require(percent>0.0){"percent is illegal"}

        return price-(price*percent/100)
    }

}