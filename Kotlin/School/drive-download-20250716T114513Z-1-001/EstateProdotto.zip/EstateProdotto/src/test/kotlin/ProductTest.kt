import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.*

class ProductTest {

    @Test
    fun codeVal_Is_Illegal_Empty() {
        assertThrows<IllegalArgumentException> { Product("", "Sample product", 100.0) }
    }

    @Test
    fun codeVal_Is_Illegal_Blank() {
        assertThrows<IllegalArgumentException> { Product("   ", "Sample product", 100.0) }
    }

    @Test
    fun descriptionVal_Is_Illegal_Empty() {
        assertThrows<IllegalArgumentException> { Product("PRD001", "", 100.0) }
    }

    @Test
    fun descriptionVal_Is_Illegal_Blank() {
        assertThrows<IllegalArgumentException> { Product("PRD001", "   ", 100.0) }
    }

    @Test
    fun priceVal_Is_Illegal_Negative() {
        assertThrows<IllegalArgumentException> { Product("PRD001", "Sample product", -10.0) }
    }

    @Test
    fun priceVal_Is_Illegal_Zero() {
        assertThrows<IllegalArgumentException> { Product("PRD001", "Sample product", 0.0) }
    }

    @Test
    fun product_Creation_Is_Legal() {
        assertDoesNotThrow { Product("PRD001", "Sample product", 100.0) }
    }

    @Test
    fun findSalePrice_Is_Correct_Positive_Discount() {
        val product = Product("PRD001", "Sample product", 100.0)
        assertEquals(90.0, product.findSalePrice(10.0), 0.01) // 10% discount
    }

    @Test
    fun findSalePrice_Is_Correct_Large_Discount() {
        val product = Product("PRD001", "Sample product", 100.0)
        assertEquals(50.0, product.findSalePrice(50.0), 0.01) // 50% discount
    }

    @Test
    fun findSalePrice_Is_Correct_Small_Discount() {
        val product = Product("PRD001", "Sample product", 100.0)
        assertEquals(99.0, product.findSalePrice(1.0), 0.01) // 1% discount
    }

    @Test
    fun findSalePrice_Is_Illegal_Discount_Negative() {
        val product = Product("PRD001", "Sample product", 100.0)
        assertThrows<IllegalArgumentException> { product.findSalePrice(-10.0) }
    }

    @Test
    fun findSalePrice_Is_Illegal_Discount_Zero() {
        val product = Product("PRD001", "Sample product", 100.0)
        assertThrows<IllegalArgumentException> { product.findSalePrice(0.0) }
    }
}
