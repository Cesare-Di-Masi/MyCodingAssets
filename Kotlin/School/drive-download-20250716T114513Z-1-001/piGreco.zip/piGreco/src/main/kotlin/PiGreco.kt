class PiGreco {

    fun calculate(n:Int):Double{
        require(n>0){"Number must be greater than 0"}
        var calculatedPiGreco=0.0

        for (i in 1..n){
            var changeSign=1
            calculatedPiGreco+=changeSign/i.toDouble()
            changeSign*=-1

        }
        return calculatedPiGreco
    }

}