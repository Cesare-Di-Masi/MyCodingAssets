fun main(args: Array<String>) {
    val piGreco = PiGreco()

    println(piGreco.calculate(1))
    println(piGreco.calculate(10))
    println(piGreco.calculate(100))
    println(piGreco.calculate(1000))
}
