import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

class LoanClassTest{

    @Test
    fun interestRateValueIsIllegal(){
        org.junit.jupiter.api.assertThrows<IllegalArgumentException> { val loanTest=LoanClass(-2) }
    }

    @Test
    fun interestRateValueIlLegal(){
        assertDoesNotThrow { val loanTest=LoanClass(2) }
    }

    @Test
    fun loanValueIsIllegal(){
        val loanTest=LoanClass(2)
        org.junit.jupiter.api.assertThrows<IllegalArgumentException> { loanTest.findTotalImport(-10000,20) }
    }

    @Test
    fun numberOfRateValueIsIllegal(){
        val loanTest=LoanClass(2)
        org.junit.jupiter.api.assertThrows<IllegalArgumentException> { loanTest.findTotalImport(10000,-20) }
    }

    @Test
    fun loanValueIsLegal(){
        val loanTest=LoanClass(2)
        assertDoesNotThrow { loanTest.findTotalImport(10000,20) }

    }

    @Test
    fun numberOfRateValueIsLegal(){
        val loanTest=LoanClass(2)
        assertDoesNotThrow { loanTest.findTotalImport(10000,20) }

    }

    @Test
    fun findTotalImportIsCorrect(){
        val loanTest=LoanClass(2)
        assertEquals(12100,loanTest.findTotalImport(10000,20))
    }

}