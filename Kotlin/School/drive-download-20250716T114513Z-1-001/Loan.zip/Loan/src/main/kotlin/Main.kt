fun main(args: Array<String>) {

    val n=LoanClass(2)
    println(n.findTotalImport(10000,20))

}