class LoanClass(interestRateValue:Int) {

    init {
        require(interestRateValue>=0){"the interest rate must be a natural number"}
    }

    val interestRate=interestRateValue

    fun findTotalImport(loanValue:Int,numberOfRateValue:Int):Int{
        require(loanValue>0){"the loan must be more than 0"}
        require(numberOfRateValue>0){"the number of rate must be more than 0"}
        var loan=loanValue
        val moneyPerRate=(loanValue/numberOfRateValue).toInt()
        var counter=0
        var totalImport=0
        while (counter!=numberOfRateValue){
            totalImport+=moneyPerRate+interestRate*loan/100
            counter++
            loan-=moneyPerRate
        }
        return totalImport
    }

}