import kotlin.math.round

class TemperatureSensor(temperatureCelsius: Double) {

    val COSTANTE_CONVERSIONE_CELSIUS_KELVIN = 273.15


    init {
        require(temperatureCelsius>-COSTANTE_CONVERSIONE_CELSIUS_KELVIN){"Temperatura non può essere minore a 273 gradi celsius"}
    }

     var temperatureC=temperatureCelsius
         private set

     val temperatureF:Double
         get() = (temperatureC*(9/5))+32

     val temperatureK:Double
         get() = temperatureC+273.15

}