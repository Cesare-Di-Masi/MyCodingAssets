import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import java.lang.IllegalArgumentException


class MyMath2Test(){

    @Test
    fun number1IsNotNatural(){
        assertThrows<IllegalArgumentException> { val myMathTest=MyMath2(-1,1,2) }
    }

    @Test
    fun number1IsCorrect(){
        assertDoesNotThrow { val myMathTest=MyMath2(1,1,2) }
    }

    @Test
    fun number2IsNotNatural(){
        assertThrows<IllegalArgumentException> { val myMathTest=MyMath2(1,-1,2) }
    }

    @Test
    fun number2IsCorrect(){
        assertDoesNotThrow { val myMathTest=MyMath2(1,1,2) }
    }

    @Test
    fun numberFibIsNotNatural(){
        assertThrows<IllegalArgumentException> { val myMathTest=MyMath2(1,1,-2) }
    }

    @Test
    fun numberFibIsCorrect(){
        assertDoesNotThrow { val myMathTest=MyMath2(1,1,2) }
    }

    @Test
    fun constructorIsCorrect(){
        assertDoesNotThrow { val myMathTest=MyMath2(1,1,2) }
    }

    @Test
    fun getMCDIsCorrect(){
        val myMathTest=MyMath2(10,5,2)
        assertEquals(5,myMathTest.mcd)
    }

    @Test
    fun getFibonacciSuccessionsCorrect(){
        val myMathTest=MyMath2(10,5,2)
        assertEquals(3,myMathTest.fibonacciSuccession)
    }

}