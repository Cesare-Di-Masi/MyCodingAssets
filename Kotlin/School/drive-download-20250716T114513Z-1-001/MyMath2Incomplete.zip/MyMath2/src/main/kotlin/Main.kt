fun main(args: Array<String>) {

    val n=MyMath2(8,16,1)

    println(n.mcd)
    println(n.fibonacciSuccession)

}