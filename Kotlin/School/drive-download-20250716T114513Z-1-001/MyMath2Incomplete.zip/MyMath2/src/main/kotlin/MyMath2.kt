class MyMath2(number1Value:Int, number2Value:Int, numberFibValue:Int) {

    init {
        require(number1Value>=0){"Number 1 has to be natural"}
        require(number2Value>=0){"Number 2 has to be natural"}
        require(numberFibValue>=0){"Number for the Fibonacci succession has to be natural"}
    }

    val number1=number1Value
    val number2=number2Value
    val numberFib=numberFibValue
    val mcd:Int
        get() {
            var x = number1
            var y = number2
            while (y != 0) {
                val temp = y
                y = x % y
                x = temp
            }
            return x}

    var fibonacciSuccession:Int = 0
        get() {
            field=numberFib+numberFib-1
            return field
        }



}