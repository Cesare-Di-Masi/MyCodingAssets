import org.junit.jupiter.api.*

import org.junit.jupiter.api.Assertions.*

class WorkerTest {

    @Test
    fun nameValue_Is_Illegal_Blank() {
        val week=Array<Int>(7){1}
        assertThrows<IllegalArgumentException> { val testWorker=Worker(" ",week) }
    }

    @Test
    fun nameValue_Is_Illegal_Empty() {
        val week=Array<Int>(7){1}
        assertThrows<IllegalArgumentException> { val testWorker=Worker("",week) }
    }

    @Test
    fun hoursWorkedValue_Is_Illegal_Size_tooSmall() {
        val week=Array<Int>(6){1}
        assertThrows<IllegalArgumentException> { val testWorker=Worker("John",week) }
    }

    @Test
    fun hoursWorkedValue_Is_Illegal_Size_tooBig() {
        val week=Array<Int>(8){1}
        assertThrows<IllegalArgumentException> { val testWorker=Worker("John",week) }
    }

    @Test
    fun hoursWorkedValue_Is_Illegal_Hours_Negative() {
        val week=Array<Int>(7){-1}
        assertThrows<IllegalArgumentException> { val testWorker=Worker("John",week) }
    }

    @Test
    fun hoursWorkedValue_Is_Illegal_Hours_tooBig() {
        val week=Array<Int>(7){25}
        assertThrows<IllegalArgumentException> { val testWorker=Worker("John",week) }
    }

    @Test
    fun nameValue_Is_Legal() {
        val week=Array<Int>(7){1}
        assertDoesNotThrow { val testWorker=Worker("John",week) }
    }

    @Test
    fun hoursWorkedValue_Is_Legal() {
        val week=Array<Int>(7){1}
        assertDoesNotThrow { val testWorker=Worker("John",week) }
    }

    @Test
    fun addHours_day_Is_Illegal_tooSmall() {
        val week=Array<Int>(7){1}
        val testWorker=Worker("John",week)
        assertThrows<IllegalArgumentException> { testWorker.addHours(0,2) }
    }

    @Test
    fun addHours_day_Is_Illegal_tooBig() {
        val week=Array<Int>(7){1}
        val testWorker=Worker("John",week)
        assertThrows<IllegalArgumentException> { testWorker.addHours(8,2) }
    }

    @Test
    fun addHours_hours_Is_Illegal_Negative() {
        val week=Array<Int>(7){1}
        val testWorker=Worker("John",week)
        assertThrows<IllegalArgumentException> { testWorker.addHours(7,-1) }
    }

    @Test
    fun addHours_hours_Is_Illegal_tooBig() {
        val week=Array<Int>(7){1}
        val testWorker=Worker("John",week)
        assertThrows<IllegalArgumentException> { testWorker.addHours(7,25) }
    }

    @Test
    fun addHours_day_Is_Legal() {
        val week=Array<Int>(7){1}
        val testWorker=Worker("John",week)
        assertDoesNotThrow { testWorker.addHours(7,2) }
    }

    @Test
    fun addHours_hours_Is_Legal() {
        val week=Array<Int>(7){1}
        val testWorker=Worker("John",week)
        assertDoesNotThrow { testWorker.addHours(7,2) }
    }

    @Test
    fun addHours_Is_Correct() {
        val week=Array<Int>(7){1}
        val expected=Array<Int>(7){1}
        expected[0]=2
        val testWorker=Worker("John",week)
        testWorker.addHours(1,2)
        assertArrayEquals(expected,testWorker.hoursWorked)
    }

    @Test
    fun totHoursWorked_Is_Correct() {
        val week=Array<Int>(7){1}
        val testWorker=Worker("John",week)
        assertEquals(7,testWorker.totDaysWorked())
    }

    @Test
    fun totDaysWorkedAtLeastFourHours_Is_Correct() {
        val week=Array<Int>(7){4}
        val testWorker=Worker("John",week)
        assertEquals(7,testWorker.totDaysWorkedAtLeastFourHours())
    }

    @Test
    fun totDaysWorkedAtLeastSixHours_Is_Correct() {
        val week=Array<Int>(7){6}
        val testWorker=Worker("John",week)
        assertEquals(7,testWorker.totDaysWorkedAtLeastSixHours())
    }

    @Test
    fun totDaysWorked_Is_Correct() {
        val week=Array<Int>(7){1}
        val testWorker=Worker("John",week)
        testWorker.addHours(1,0)
        assertEquals(6,testWorker.totDaysWorked())
    }

    @Test
    fun calculateAverageHoursWorked_Is_Correct() {
        val week=Array<Int>(7){2}
        val testWorker=Worker("John",week)
        assertEquals(2,testWorker.calculateAverageHoursWorked())
    }

    @Test
    fun calculateSalary_salaryPerHour_Is_Illegal_Negative() {
        val week=Array<Int>(7){2}
        val testWorker=Worker("John",week)
        assertThrows<IllegalArgumentException> { testWorker.calculateSalary(-1.0) }
    }
    @Test
    fun calculateSalary_salaryPerHour_Is_Illegal_0() {
        val week=Array<Int>(7){2}
        val testWorker=Worker("John",week)
        assertThrows<IllegalArgumentException> { testWorker.calculateSalary(0.0) }
    }

    @Test
    fun calculateSalary_salaryPerHour_Is_Legal(){
        val week=Array<Int>(7){2}
        val testWorker=Worker("John",week)
        assertDoesNotThrow { testWorker.calculateSalary(1.0) }
    }

    @Test
    fun calculateSalary_salaryPerHour_Is_Correct(){
        val week=Array<Int>(7){2}
        val testWorker=Worker("John",week)
        assertEquals(14.0,testWorker.calculateSalary(1.0))
    }


}