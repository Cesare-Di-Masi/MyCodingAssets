class Worker(nameValue:String, hoursWorkedValue:Array<Int>) {

    init {
        require(nameValue.isNotBlank()&&nameValue.isNotEmpty()){"illegal name"}
        require(hoursWorkedValue.size==7){"Illegal hours worked size"}
        for (i in hoursWorkedValue)
            require(i in 0..24){"Illegal hours worked"}
    }
    val hoursWorked=hoursWorkedValue

    fun addHours(day:Int,hours:Int){
        require(day in 1..7){"illegal day"}
        require(hours in 0..24){"illegal hours"}
        hoursWorked[day-1]=hours
    }

    fun totHoursWorked():Int{
        var counterH=0
        for (i in hoursWorked)
            counterH+=i
        return counterH
    }

    fun totDaysWorkedAtLeastFourHours():Int{
        var counterD=0
        for (i in hoursWorked){
            if (i>=4)
                counterD++
        }
        return counterD
    }

    fun totDaysWorkedAtLeastSixHours():Int{
        var counterD=0
        for (i in hoursWorked){
            if (i>=6)
                counterD++
        }
        return counterD
    }

    fun totDaysWorked():Int{
        var counterD=0
        for (i in hoursWorked){
            if (i>0)
                counterD++
        }
        return counterD
    }

    fun calculateAverageHoursWorked():Int{
        return totHoursWorked()/totDaysWorked()
    }

    fun calculateSalary(salaryPerHour:Double):Double{
        require(salaryPerHour>0){"illegal salary, literally"}
        return totHoursWorked()*salaryPerHour
    }

}