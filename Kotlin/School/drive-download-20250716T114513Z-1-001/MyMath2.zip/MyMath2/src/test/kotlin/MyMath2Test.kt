import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import java.lang.IllegalArgumentException



class MyMath2Test(){

    @Test
    fun copriminumber1IsNotNatural(){
        val myMathTest=MyMath2()
        assertThrows<IllegalArgumentException> { myMathTest.coprimi(-1,1) }
    }

    @Test
    fun coprimiNumber1IsCorrect(){
        val myMathTest=MyMath2()
        assertDoesNotThrow { myMathTest.coprimi(1,1) }
    }

    @Test
    fun copriminumber2IsNotNatural(){
        val myMathTest=MyMath2()
        assertThrows<IllegalArgumentException> { myMathTest.coprimi(1,-11) }
    }

    @Test
    fun coprimiNumber2IsCorrect(){
        val myMathTest=MyMath2()
        assertDoesNotThrow { myMathTest.coprimi(1,1) }
    }

    @Test
    fun coprimiIsCorrect(){
        val myMayhTest=MyMath2()
        assertEquals(true, myMayhTest.coprimi(1,1))
    }

    @Test
    fun MCDnumber1IsNotNatural(){
        val myMathTest=MyMath2()
        assertThrows<IllegalArgumentException> { myMathTest.coprimi(-1,1) }
    }

    @Test
    fun MCDNumber1IsCorrect(){
        val myMathTest=MyMath2()
        assertDoesNotThrow { myMathTest.coprimi(1,1) }
    }

    @Test
    fun MCDnumber2IsNotNatural(){
        val myMathTest=MyMath2()
        assertThrows<IllegalArgumentException> { myMathTest.coprimi(1,-11) }
    }

    @Test
    fun MCDNumber2IsCorrect(){
        val myMathTest=MyMath2()
        assertDoesNotThrow { myMathTest.coprimi(1,1) }
    }

    @Test
    fun MCDIsCorrect(){
        val myMayhTest=MyMath2()
        assertEquals(true, myMayhTest.coprimi(1,1))
    }

}