fun main(args: Array<String>) {

    val n=MyMath2()
    println(n.calculateMCD(13,17))
    println(n.coprimi(78,14))
    println(n.amicabili(12,34))
    println(n.calculateFibonacciSuccession(50))

}