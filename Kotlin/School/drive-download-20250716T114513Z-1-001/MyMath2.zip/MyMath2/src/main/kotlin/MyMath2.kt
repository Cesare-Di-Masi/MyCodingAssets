class MyMath2() {

    /*init {
        require(number1Value>=0){"Number 1 has to be natural"}
        require(number2Value>=0){"Number 2 has to be natural"}
        require(numberFibValue>=0){"Number for the Fibonacci succession has to be natural"}
    }
    */

    fun coprimi(number1Value: Int,number2Value: Int):Boolean{

        require(number1Value>=0&& number2Value>=0){"Numbers have to be natural"}

        return calculateMCD(number1Value,number2Value)==1
    }

    fun calculateMCD(number1Value:Int, number2Value:Int):Int {

        require(number1Value>=0&& number2Value>=0){"Numbers have to be natural"}

        if (number1Value==0&&number2Value==0) return 0

        var rest:Int
        var number1 = number1Value
        var number2 = number2Value
        while (number2 != 0) {
            rest = number1%number2
            number1 =number2
            number2 = rest

            }
            return number1
    }

    fun sumDivisorsMy(number:Int):Int{

        var sumDivisorsNumber=0

        for (i  in 1..<number/2){

            if (i%number==0)
                sumDivisorsNumber+=i

        }
        return sumDivisorsNumber

    }

    fun amicabili(number1Value: Int, number2Value: Int):Boolean{

        require(number1Value>=0&& number2Value>=0){"Numbers have to be natural"}

       val sumDivisorsNumber1=sumDivisorsMy(number1Value)
        if (sumDivisorsNumber1==number2Value){
            val sumDivisorsNumber2=sumDivisorsMy(number2Value)
            return sumDivisorsNumber2==number1Value
        }
        return false
    }

    fun calculateFibonacciSuccession(numberFibValue:Int):Long{

        require(numberFibValue>0){"The number has to be natural and more than 0"}
        if (numberFibValue==1) return 0
        if (numberFibValue==2) return 1

        var previous1:Long=1
        var previous2:Long=0
        var valute:Long=0

        for (i in 3..numberFibValue){
            valute= previous2+previous1
            previous2=previous1
            previous1=valute
        }

        return valute

    }


}