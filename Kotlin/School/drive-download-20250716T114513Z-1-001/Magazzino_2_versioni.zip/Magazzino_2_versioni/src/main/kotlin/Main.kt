fun main(args: Array<String>) {
    val magazzinop1_1=Storage1("Farfalle",1.5,450,3)
    val magazzinop1_2=Storage1("Fusilli",2.0,347,7)
    val magazzinop1_3=Storage1("Penne",1.75,563,6)
    val magazzinop2_1=Storage2(1,1.5,450,3)
    val magazzinop2_2=Storage2(2,2.0,347,7)
    val magazzinop2_3=Storage2(3,1.75,563,6)


    magazzinop1_1.buyingProducts(30)
    magazzinop1_1.sellingProducts(8)
    println(magazzinop1_1)
    magazzinop1_2.buyingProducts(43)
    magazzinop1_2.sellingProducts(7)
    println(magazzinop1_2)
    magazzinop1_3.buyingProducts(65)
    magazzinop1_3.sellingProducts(32)
    println(magazzinop1_3)
    magazzinop2_1.buyingProducts(30)
    magazzinop2_1.sellingProducts(8)
    
    println(magazzinop2_1)
    magazzinop2_2.buyingProducts(43)
    magazzinop2_2.sellingProducts(7)
    println(magazzinop2_2)
    magazzinop2_3.buyingProducts(65)
    magazzinop2_3.sellingProducts(32)
    println(magazzinop2_3)
}