class Storage2(codeValue:Int, sellPriceValue:Double, quantityValue:Int, increaseValue:Int) {

    init {
        require(quantityValue>=0){"La quantità non può essere inferiore a 0."}
        require(sellPriceValue>0){"il prezzo di vendita deve essere maggiore di 0."}
        require(increaseValue>0){"Lo sconto deve essere maggiore di 0"}
    }

    val code=codeValue
    val sellPrice=sellPriceValue
    var quantity=quantityValue
    val increase=increaseValue

    fun buyingProducts(buyQuantity:Int){

        require(buyQuantity>0){"Acquistare più di 0 prodotti"}

        quantity+=buyQuantity
        var totPrice= buyQuantity*sellPrice
        var increasing= totPrice/100
        totPrice+= increasing
    }

    fun sellingProducts(sellQuantity:Int):Double{

        quantity-=sellQuantity

        var totPrice= sellQuantity*sellPrice
        val increasing = totPrice/100
        totPrice+= increasing
        return totPrice

    }

    override fun toString(): String {
        return "$code prezzo di vendita : $sellPrice. Quantità : $quantity"
    }

}


