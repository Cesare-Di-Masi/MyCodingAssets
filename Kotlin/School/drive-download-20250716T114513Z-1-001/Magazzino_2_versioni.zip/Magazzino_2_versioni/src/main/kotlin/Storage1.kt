class Storage1(NameValue:String, sellPriceValue:Double,quantityValue:Int,qtyDiscountValue:Int) {

    init {
        require(NameValue.isNotBlank()){"Il prodotto deve avere un nominativo proprio."}
        require(quantityValue>=0){"La quantità non può essere inferiore a 0."}
        require(sellPriceValue>0){"il prezzo di vendita deve essere maggiore di 0."}
        require(qtyDiscountValue>0){"Lo sconto deve essere maggiore di 0"}
    }

    val Name=NameValue
    val sellPrice=sellPriceValue
    var quantity=quantityValue
    val qtyDiscount=qtyDiscountValue

    fun buyingProducts(buyQuantity:Int){

        require(buyQuantity>0){"Acquistare più di 0 prodotti"}

        quantity+=buyQuantity
    }

    fun sellingProducts(sellQuantity:Int):Double{

        quantity-=sellQuantity

        var totPrice= sellQuantity*sellPrice

        if (sellQuantity>=qtyDiscount)
        {

            val discount = totPrice/100

            totPrice-= discount

        }

        return totPrice

    }

    override fun toString(): String {
        return "$Name prezzo di vendita : $sellPrice. Quantità : $quantity"
    }

}