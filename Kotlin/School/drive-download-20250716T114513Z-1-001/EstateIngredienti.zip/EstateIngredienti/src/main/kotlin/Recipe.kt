class Recipe(ingredientsVal:Array<Int>) {

    init {
        for (i in ingredientsVal)
            require(i>0){"illegal ingredients"}
    }

    val ingredients=ingredientsVal

    fun nIngredients():Int{
        return ingredients.size
    }

    fun giveAnIngredientsQuantity(number:Int):Int{
        require(number in 1..ingredients.size)
        return ingredients[number-1]
    }

    fun giveTotRecipeWeight():Int{
        var tot=0
        for (i in ingredients)
            tot+=i
        return tot
    }

    fun giveLeastIngredientQuantity():Int{
        var least=0
        for (i in ingredients){
            if (least<i)
                least=i
        }
        return  least
    }

}