import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.*

class RecipeTest {

    @Test
    fun ingredientsVal_Is_Illegal_Negative_Value() {
        val ingredients = arrayOf(1, 2, -3, 4)
        assertThrows<IllegalArgumentException> { Recipe(ingredients) }
    }

    @Test
    fun ingredientsVal_Is_Illegal_Zero_Value() {
        val ingredients = arrayOf(1, 0, 3, 4)
        assertThrows<IllegalArgumentException> { Recipe(ingredients) }
    }

    @Test
    fun ingredientsVal_Is_Legal_Positive_Values() {
        val ingredients = arrayOf(1, 2, 3, 4)
        assertDoesNotThrow { Recipe(ingredients) }
    }

    @Test
    fun nIngredients_Returns_Correct_Count() {
        val ingredients = arrayOf(1, 2, 3, 4)
        val recipe = Recipe(ingredients)
        assertEquals(4, recipe.nIngredients())
    }

    @Test
    fun giveAnIngredientsQuantity_Returns_Correct_Quantity() {
        val ingredients = arrayOf(1, 2, 3, 4)
        val recipe = Recipe(ingredients)
        assertEquals(3, recipe.giveAnIngredientsQuantity(3))
    }

    @Test
    fun giveAnIngredientsQuantity_Is_Illegal_Index_Too_Low() {
        val ingredients = arrayOf(1, 2, 3, 4)
        val recipe = Recipe(ingredients)
        assertThrows<IllegalArgumentException> { recipe.giveAnIngredientsQuantity(0) }
    }

    @Test
    fun giveAnIngredientsQuantity_Is_Illegal_Index_Too_High() {
        val ingredients = arrayOf(1, 2, 3, 4)
        val recipe = Recipe(ingredients)
        assertThrows<IllegalArgumentException> { recipe.giveAnIngredientsQuantity(5) }
    }

    @Test
    fun giveTotRecipeWeight_Returns_Correct_Total() {
        val ingredients = arrayOf(1, 2, 3, 4)
        val recipe = Recipe(ingredients)
        assertEquals(10, recipe.giveTotRecipeWeight())
    }

    @Test
    fun giveLeastIngredientQuantity_Returns_Correct_Min() {
        val ingredients = arrayOf(5, 1, 8, 3)
        val recipe = Recipe(ingredients)
        assertEquals(8, recipe.giveLeastIngredientQuantity())
    }

    @Test
    fun giveLeastIngredientQuantity_Returns_Correct_Min_Single_Value() {
        val ingredients = arrayOf(5)
        val recipe = Recipe(ingredients)
        assertEquals(5, recipe.giveLeastIngredientQuantity())
    }
}
