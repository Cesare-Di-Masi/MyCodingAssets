import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import kotlin.IllegalArgumentException


class TrafficLightTest {

    //test di correttezza
    @Test
    fun isLigthOn_OnPrevOff_True()
    {
        //semaforo attivo dalle 4 alle 22
        val trafficLight = TrafficLight(60,22,0,4,0)
        assertEquals(true, trafficLight.isTrafficLightOn(4,10,20))
    }
    @Test
    fun isLigthOn_OnPrevOff_False()
    {
        //semaforo attivo dalle 4 alle 22
        val trafficLight = TrafficLight(60,22,0,4,0)
        assertEquals(false, trafficLight.isTrafficLightOn(22,10,20))
    }
    @Test
    fun isLigthOn_OffPrevOn_True()
    {
        //semaforo attivo dalle 22 alle 4
        val trafficLight = TrafficLight(60,4,0,22,0)
        assertEquals(true, trafficLight.isTrafficLightOn(22,10,20))
    }
    @Test
    fun isLigthOn_OffPrevOn_False()
    {
        //semaforo attivo dalle 22 alle 4
        val trafficLight = TrafficLight(60,4,0,22,0)
        assertEquals(false, trafficLight.isTrafficLightOn(5,10,20))
    }


    @Test
    fun isLigthOff_OnPrevOff_True()
    {
        //semaforo attivo dalle 4 alle 22
        val trafficLight = TrafficLight(60,22,0,4,0)
        assertEquals(true, trafficLight.isTrafficLightOff(3,10,20))
    }
    @Test
    fun isLigthOff_OnPrevOff_False()
    {
        //semaforo attivo dalle 4 alle 22
        val trafficLight = TrafficLight(60,22,0,4,0)
        assertEquals(false, trafficLight.isTrafficLightOff(21,10,20))
    }
    @Test
    fun isLigthOff_OffPrevOn_True()
    {
        //semaforo attivo dalle 22 alle 4
        val trafficLight = TrafficLight(60,4,0,22,0)
        assertEquals(true, trafficLight.isTrafficLightOff(21,10,20))
    }
    @Test
    fun isLigthOff_OffPrevOn_False()
    {
        //semaforo attivo dalle 22 alle 4
        val trafficLight = TrafficLight(60,4,0,22,0)
        assertEquals(false, trafficLight.isTrafficLightOff(23,10,20))
    }

    @Test
    fun findLightColour_OnPrevOff_Green()
    {
        //semaforo attivo dalle 4 alle 22
        val trafficLight = TrafficLight(60,22,0,4,0)
        assertEquals(TrafficLight.lightColourValues.Green, trafficLight.findLightColour(4,0,1))

    }
    @Test
    fun findLightColour_OnPrevOff_Orange()
    {
//semaforo attivo dalle 4 alle 22
        val trafficLight = TrafficLight(60,22,0,4,0)
        assertEquals(TrafficLight.lightColourValues.Orange, trafficLight.findLightColour(4,1,11))

    }
    @Test
    fun findLightColour_OnPrevOff_Red()
    {
//semaforo attivo dalle 4 alle 22
        val trafficLight = TrafficLight(60,22,0,4,0)
        assertEquals(TrafficLight.lightColourValues.Red, trafficLight.findLightColour(4,1,31))

    }
    @Test
    fun findLightColour_OffPrevOn_Green()
    {
        //semaforo attivo dalle 22 alle 4
        val trafficLight = TrafficLight(60,4,0,22,0)
        assertEquals(TrafficLight.lightColourValues.Green, trafficLight.findLightColour(22,0,31))


    }
    @Test
    fun findLightColour_OffPrevOn_Orange()
    {
        //semaforo attivo dalle 22 alle 4
        val trafficLight = TrafficLight(60,4,0,22,0)
        assertEquals(TrafficLight.lightColourValues.Orange, trafficLight.findLightColour(22,1,11))


    }
    @Test
    fun findLightColour_OffPrevOn_Red()
    {
        //semaforo attivo dalle 22 alle 4
        val trafficLight = TrafficLight(60,4,0,22,0)
        assertEquals(TrafficLight.lightColourValues.Red, trafficLight.findLightColour(22,1,37))

    }



/*
    //test di accettabilita
    @Test
    fun lightTimeValueIsNegative(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(-1,23,0,4,0) }
    }

    @Test
    fun lightTimeValueIsZero(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(0,23,0,4,0) }
    }

    @Test
    fun lighTimeValueIsCorrect(){
        assertDoesNotThrow { val lightTest=TrafficLight(60,23,0,4,0) }
    }

    @Test
    fun hourPowerOnValueIsNegative(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,0,-1,0) }
    }

    @Test
    fun hourPowerOnValueIsGreaterThan23(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,0,24,0) }
    }

    @Test
    fun hourPowerOnValueIsCorrect(){
        assertDoesNotThrow { val lightTest=TrafficLight(60,23,0,4,0) }
    }

    @Test
    fun hourShuttingDownValueIsNegative(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,-1,0,4,0) }
    }

    @Test
    fun hourShuttingDownValueIsGreaterThan23(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,24,0,24,0) }
    }

    @Test
    fun hourShuttingDownValueIsCorrect(){
        assertDoesNotThrow { val lightTest=TrafficLight(60,23,0,4,0) }
    }

    @Test
    fun minutePowerOnIsNegative(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,0,4,-1) }
    }

    @Test
    fun minutePowerOnIsGreaterThan59(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,0,4,60) }
    }

    @Test
    fun minutePowerOnValueIsCorrect(){
        assertDoesNotThrow { val lightTest=TrafficLight(60,23,0,4,0) }
    }

    @Test
    fun minuteShuttingDownValueIsNegative(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,-1,4,0) }
    }

    @Test
    fun minuteShuttingDownValueIsGreaterThan59(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,60,4,0) }
    }

    @Test
    fun minuteShuttingDownValueIsCorrect(){
        assertDoesNotThrow { val lightTest=TrafficLight(60,23,0,4,0) }
    }

    @Test
    fun findLightHoursValueIsNegative(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLightColour(-1,0,0) }
    }

    @Test
    fun findLightHoursValueIsGreaterThan23(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLightColour(24,0,0) }
    }

    @Test
    fun findLightHoursValueValueIsCorrect(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertDoesNotThrow { lightTest.findLightColour(4,0,0) }
    }

    @Test
    fun findLightMinutesValueIsNegative(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLightColour(4,-1,0) }
    }

    @Test
    fun findLightMinutesValueIsGreaterThan59(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLightColour(4,60,0) }
    }

    @Test
    fun findLightMinutesValueValueIsCorrect(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertDoesNotThrow { lightTest.findLightColour(4,0,0) }
    }

    @Test
    fun findLightSecondsValueIsNegative(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLightColour(4,0,-1) }
    }

    @Test
    fun findLightSecondsValueIsGreaterThan59(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLightColour(4,0,60) }
    }

    @Test
    fun findLightSecondsValueValueIsCorrect(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertDoesNotThrow { lightTest.findLightColour(4,0,0) }
    }
*/
}