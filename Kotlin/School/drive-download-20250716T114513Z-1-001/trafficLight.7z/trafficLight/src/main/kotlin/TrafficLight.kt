class TrafficLight( lightTimeValue:Int,hourShuttingDownValue:Int,minuteShuttingDownValue:Int,
                    hourPowerOnValue:Int, minutePowerOnValue:Int) {

    val HOUR_RANGE = 0..23
    val MIN_RANGE = 0..59

    private val minorTimeInSeconds:Int
    private val greaterTimeInSeconds:Int

    init {

        require(lightTimeValue>0){"lightTime must greater than 0"}
        require(hourPowerOnValue in HOUR_RANGE){"hoursPowerOn must be between 0 and 23"}
        require(hourShuttingDownValue in HOUR_RANGE){"hoursShuttingDown must be between 0 and 23"}
        require(minutePowerOnValue in MIN_RANGE){"minutesPowerOn must be between 0 and 59"}
        require(minuteShuttingDownValue in MIN_RANGE){"minutesShuttingDown must be between 0 and 59"}

        if (hourPowerOnValue>hourShuttingDownValue){
            minorTimeInSeconds = hourShuttingDownValue * 3600 + minuteShuttingDownValue * 60
            greaterTimeInSeconds = hourPowerOnValue * 3600 + minutePowerOnValue * 60
        }else{

            minorTimeInSeconds = hourPowerOnValue * 3600 + minutePowerOnValue * 60
            greaterTimeInSeconds = hourShuttingDownValue * 3600 + minuteShuttingDownValue * 60
        }
    }

    //public val attributo di sola lettura
    private val greenTime=lightTimeValue
    private val orangeTime=lightTimeValue/2
    private val redTime=lightTimeValue
    private val lightCycleTime=greenTime+orangeTime+redTime


    enum class lightColourValues{
        Red,Orange,Green
    }

    fun isTrafficLightOn(hoursValue:Int,minutesValue:Int,secondsValue:Int):Boolean{

        require(hoursValue in HOUR_RANGE) { "hours must be between 0 and 23" }
        require(minutesValue in MIN_RANGE) { "minutes must be between 0 and 59" }
        require(secondsValue in MIN_RANGE) { "seconds must be between 0 and 59" }

        val timeInSeconds = hoursValue * 3600 + minutesValue * 60 + secondsValue
        return timeInSeconds>=greaterTimeInSeconds||timeInSeconds<=minorTimeInSeconds

    }

    fun isTrafficLightOff(hoursValue:Int,minutesValue:Int,secondsValue:Int):Boolean{
        return !isTrafficLightOn(hoursValue,minutesValue,secondsValue)
    }

    fun findLightColour(hoursValue:Int, minutesValue:Int, secondsValue:Int):lightColourValues {

        require(hoursValue in HOUR_RANGE) { "hours must be between 0 and 23" }
        require(minutesValue in MIN_RANGE) { "minutes must be between 0 and 59" }
        require(secondsValue in MIN_RANGE) { "seconds must be between 0 and 59" }

        //trasformo il tempo in secondo
        val timeInSeconds = hoursValue * 3600 + minutesValue * 60 + secondsValue

        //verifico quale colore del semaforo
        return when {
            timeInSeconds in greaterTimeInSeconds..minorTimeInSeconds -> lightColourValues.Orange
            timeInSeconds % lightCycleTime < greenTime -> lightColourValues.Green
            timeInSeconds % lightCycleTime < greenTime + orangeTime -> lightColourValues.Orange
            else -> lightColourValues.Red
        }

    }

}