fun main(args: Array<String>) {

    val trafficLight=TrafficLight(60,22,0,4,0)
    println(trafficLight.isTrafficLightOn(4,10,20))



}