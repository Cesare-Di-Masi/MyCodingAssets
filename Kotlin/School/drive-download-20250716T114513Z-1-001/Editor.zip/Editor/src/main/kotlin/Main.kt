fun main() {

    val c=Publisher(0.25,1.0)
    println(c.calculatePriceV2(100,5))

}