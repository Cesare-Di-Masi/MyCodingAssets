import kotlin.math.pow

class Publisher( pricePerPageValue:Double, pricePerCharacterValue:Double) {


    init {
        require(pricePerPageValue>0.0){"the price per page must be more than 0"}
        require(pricePerCharacterValue>0.0){"the price per character must be more than 0"}
    }
     private val pricePerPage=pricePerPageValue
     private val pricePerCharacter=pricePerCharacterValue

    private fun calculateTotDigits(numberOfPagesforCounterValue: Int):Int{
        var numberOfPagesForCounter = numberOfPagesforCounterValue
        var counter = 0

        while (numberOfPagesForCounter != 0) {
            numberOfPagesForCounter /= 10
            counter++
        }
        return counter
    }

    /*fun calculatePrice(numberOfPagesValue:Int, numberOfCharactersValue:Int):Double {

        require(numberOfPagesValue > 0) { "number of pages must be more than 0" }
        require(numberOfCharactersValue >= 0) { "the number of characters must not be negative" }

        val totDigits = 9 + (numberOfPagesValue - 9) * calculateTotDigits(numberOfPagesValue)
        val priceForDigits = totDigits * pricePerPage
        val pricesForCharacter = numberOfCharactersValue * pricePerCharacter
        return priceForDigits + pricesForCharacter
    }*/
    fun calculatePriceV2(numberOfPagesValue:Int, numberOfCharactersValue:Int):Int{

        var numberOfPages=numberOfPagesValue
        val numberOfCharacters=numberOfCharactersValue
        val counter=calculateTotDigits(numberOfPages)
        var totPricePages:Int=0
        for (i in 0..<counter){

            totPricePages+=((numberOfPages-(9*10.0.pow(i))).toInt())
            numberOfPages/=10
        }
        return totPricePages
    }

}