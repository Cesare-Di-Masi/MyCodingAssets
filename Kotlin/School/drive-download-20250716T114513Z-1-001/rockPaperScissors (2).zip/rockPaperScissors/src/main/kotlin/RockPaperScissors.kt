class RockPaperScissors(nameValue:String) {

    init {
        require(nameValue.isNotBlank()&&nameValue.isNotEmpty()){"Digit a usable name for the player"}
    }


    val name= nameValue
    var winner:Int = 0
    private var roundsPlayed=0
    private var classMove:Int=0
    private var lastPlayerMove:Int=0
    var playerWins=0
    var classWins=0

    private fun randomNumber(): Int {
        return (1..3).random()
    }
    fun chooseGameRounds(){
        println("you are going to play Rock Paper Scissors!")
        println("for choosing your rounds choose 1 (3 rounds) 2 (5 rounds) and 3 for your custom rounds")
        var gameTypeChoose: Int = readln().toInt()
        require(gameTypeChoose in 1..3){"Choose between 1,2,3"}
        var rounds:Int=0

        when(gameTypeChoose){
            1 ->rounds=3
            2 ->rounds=5
            3 ->rounds= readln().toInt()
        }
        require(rounds>0){"the number of rounds must be a natural number and more than 0"}
        require(rounds%2==1){"the number of rounds must be an odd number"}
    }

    fun play(playerMove:Int) {
        require(playerMove in 1..3){"the chosen move must be wrote with a number between 1 and 3 (rock,paper,scissors)"}
        classMove=randomNumber()
        lastPlayerMove=playerMove

        return if (playerMove==classMove){
            winner=0
            roundsPlayed+=1
        }else{
            if (playerMove==classMove+1||(playerMove==1&&classMove==3)){
                winner=1
                roundsPlayed+=1
                playerWins+=1
            }else{
               winner=2
                roundsPlayed+=1
                classWins+=1
            }
        }


    }

    override fun toString(): String {
        return when (winner) {
            0 -> "It's a tie!(class chose $classMove Player chose $lastPlayerMove). Score: P($playerWins) C($classWins)"
            1 -> "the player wins!(class chose $classMove Player chose $lastPlayerMove). Score: P($playerWins) C($classWins)"
            else -> "the class wins!(class chose $classMove Player chose $lastPlayerMove. Score: P($playerWins) C($classWins))"
        }

    }

    }




