class Editor(pricePerPageValue:Double, pricePerCharacterValue:Double) {

    init {
        require(pricePerPageValue>0.0){"the price per page must be more than 0"}
        require(pricePerCharacterValue>0.0){"the price per character must be more than 0"}
    }
    private val pricePerPage=pricePerPageValue
    private val pricePerCharacter=pricePerCharacterValue

    fun calculatePrice(numberOfPagesValue:Int,numberOfCharactersValue:Int):Double{

        require(numberOfPagesValue>0){"number of pages must be more than 0"}
        require(numberOfCharactersValue>=0){"the number of characters must not be negative"}

        var pageForCounter=numberOfPagesValue
        var counter=0
        while (pageForCounter!=0){
            pageForCounter/=10
            counter+=1
        }

        val totDigits=9+(numberOfPagesValue-9)*counter
        val priceForDigits=totDigits*pricePerPage
        val pricesForCharacter=numberOfCharactersValue*pricePerCharacter
        return priceForDigits+pricesForCharacter
    }

}