import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*


class EditorTest{

    @Test
    fun pricePerPageValueIsIllegal(){
        assertThrows<IllegalArgumentException> { val editorTest=Editor(-1.0,5.0) }
    }

    @Test
    fun pricePerPageValueIsLegal(){
        assertDoesNotThrow { val editorTest=Editor(1.0,5.0) }
    }

    @Test
    fun pricePerCharacterValueIsIllegal(){
        assertThrows<IllegalArgumentException> { val editorTest=Editor(1.0,-5.0) }
    }

    @Test
    fun pricePerCharacterValueIsLegal(){
        assertDoesNotThrow { val editorTest=Editor(1.0,5.0) }
    }

    @Test
    fun numberOfPagesValueIsIllegal(){
        val editorTest=Editor(1.0,5.0)
        assertThrows<IllegalArgumentException> { editorTest.calculatePrice(-1,0) }
    }

    @Test
    fun numberOfPagesValueIsLegal(){
        val editorTest=Editor(1.0,5.0)
        assertDoesNotThrow { editorTest.calculatePrice(1,0) }
    }

    @Test
    fun numberOfCharactersValueIsIllegal(){
        val editorTest=Editor(1.0,5.0)
        assertThrows<IllegalArgumentException> { editorTest.calculatePrice(1,-1) }
    }

    @Test
    fun numberOfCharactersValueIsLegal(){
        val editorTest=Editor(1.0,5.0)
        assertDoesNotThrow { editorTest.calculatePrice(1,0) }
    }

    @Test
    fun calculatePriceIsCorrect(){
        val editorTest=Editor(1.0,5.0)
        assertEquals(46.0,editorTest.calculatePrice(15,5))
    }

}