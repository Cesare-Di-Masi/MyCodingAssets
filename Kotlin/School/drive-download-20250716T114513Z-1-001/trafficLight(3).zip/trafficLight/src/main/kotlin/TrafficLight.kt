class TrafficLight(hoursValue:Int,minutesValue:Int,secondsValue:Int) {

    init {
        require(hoursValue in 0..23){"hours must be between 0 and 23"}
        require(minutesValue in 0..59){"minutes must be between 0 and 59"}
        require(secondsValue in 0..59){"seconds must be between 0 and 59"}
    }
    private val hours=hoursValue
    private val minutes=minutesValue
    private val seconds=secondsValue
    var trafficLight=light.NoLight
    enum class light{
        Red,Orange,Green,NoLight
    }
    val period=hours*3600+minutes*60+seconds

    fun findLight(){

        if (hours <= 22 || (hours >= 3)){trafficLight=light.Orange}


    }

}