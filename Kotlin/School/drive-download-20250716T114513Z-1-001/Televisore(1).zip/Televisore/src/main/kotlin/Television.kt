import java.lang.reflect.TypeVariable

class Television(channelValue:Int, volumeValue:Int, isOnValue:Boolean, muteValue:Boolean) {

    init {
        require(channelValue in 1..999){"The channel must be between 1 and 999"}
        require(volumeValue in 0..100){"the volume must be between 100"}
    }

    var channel=channelValue
    var volume=volumeValue
    var isOn=isOnValue
    var mute=muteValue

    fun onOffIsPressed(){
        isOn = isOn != true
    }

    fun upVolume(){
        if (isOn==true) {
            mute = false
            if (volume == 100) {
                volume = 100
            } else {
                volume += 1
            }
        }
    }

    fun downVolume(){
        if (isOn==true) {
            mute = false
            if (volume == 0) {
                volume = 0
            } else {
                volume -= 1
                if (volume == 0) {
                    mute = true
                }
            }
        }
    }

    fun muteIsPressed(){
        if (isOn==true) {
       !mute}
    }

    fun upChannel(){
        if (isOn==true) {
            if (channel == 999) {
                volume = 1
            } else {
                channel += 1
                mute = false
            }
        }
    }

    fun downChannel(){
        if (isOn==true) {
            if (channel == 1) {
                volume = 999
            } else {
                channel -= 1
            }
        }
    }

    fun choseChannel(choseChannel:Int){
        if (isOn==true) {
            require(choseChannel in 1..999) { "Channel must be in between 1 and 999" }
            channel = choseChannel
        }
    }


    override fun toString(): String {
        return "channel:$channel, volume:$volume, is on:$isOn, is mute:$mute"
    }



}