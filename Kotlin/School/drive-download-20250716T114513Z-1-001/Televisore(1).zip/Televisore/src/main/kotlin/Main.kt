fun main(args: Array<String>) {

    val televisore=Television(12,3,true,false)

    televisore.upChannel()
    televisore.upChannel()
    televisore.upChannel()
    televisore.choseChannel(54)
    televisore.upChannel()
    televisore.downVolume()
    televisore.downVolume()
    televisore.downVolume()
    televisore.downVolume()
    televisore.onOffIsPressed()
    televisore.upVolume()
    println("Tv state: ${televisore}")

}