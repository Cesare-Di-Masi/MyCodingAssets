import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*


class TelevisionTest {

    @Test
    fun setChannel_is_below_1() {
        assertThrows<IllegalArgumentException> { val televisionTest=Television(-1,1,true,false) }
    }

    @Test
    fun setChannel_is_more_than_999() {
        assertThrows<IllegalArgumentException> { val televisionTest=Television(1000,1,true,false) }
    }

    @Test
    fun setVolume_is_below_0() {
        assertThrows<IllegalArgumentException> { val televisionTest=Television(1,-1,true,false) }
    }

    @Test
    fun setVolume_is_more_than_100() {
        assertThrows<IllegalArgumentException> { val televisionTest=Television(1,101,true,false) }
    }

    @Test
    fun setChannel_Is_Between_1_And_999_And_setVolume_Is_Between_1_And_100(){
        
    }

    @Test
    fun choseChannel() {
    }
}