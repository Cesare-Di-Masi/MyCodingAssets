import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.*

class DateTest {

    @Test
    fun monthVal_Is_Illegal_Less_Than_1() {
        assertThrows<IllegalArgumentException> { Date(10, 0, 2020) }
    }

    @Test
    fun monthVal_Is_Illegal_Greater_Than_12() {
        assertThrows<IllegalArgumentException> { Date(10, 13, 2020) }
    }

    @Test
    fun dayVal_Is_Illegal_31_Day_Month() {
        assertThrows<IllegalArgumentException> { Date(32, 1, 2020) }
    }

    @Test
    fun dayVal_Is_Illegal_30_Day_Month() {
        assertThrows<IllegalArgumentException> { Date(31, 4, 2020) }
    }

    @Test
    fun dayVal_Is_Illegal_February_Non_Leap_Year() {
        assertThrows<IllegalArgumentException> { Date(29, 2, 2021) }
    }

    @Test
    fun dayVal_Is_Illegal_February_Leap_Year() {
        assertThrows<IllegalArgumentException> { Date(30, 2, 2020) }
    }

    @Test
    fun dayVal_Is_Legal_31_Day_Month() {
        assertDoesNotThrow { Date(31, 1, 2020) }
    }

    @Test
    fun dayVal_Is_Legal_30_Day_Month() {
        assertDoesNotThrow { Date(30, 4, 2020) }
    }

    @Test
    fun dayVal_Is_Legal_February_Leap_Year() {
        assertDoesNotThrow { Date(29, 2, 2020) }
    }

    @Test
    fun dayVal_Is_Legal_February_Non_Leap_Year() {
        assertDoesNotThrow { Date(28, 2, 2021) }
    }

    @Test
    fun isLeapYear_Returns_True_For_Leap_Year() {
        val date = Date(1, 1, 2020)
        assertTrue(date.isLeapYear())
    }

    @Test
    fun isLeapYear_Returns_False_For_Non_Leap_Year() {
        val date = Date(1, 1, 2021)
        assertFalse(date.isLeapYear())
    }

    @Test
    fun isLeapYear_Returns_True_For_Divisible_By_4_Year() {
        val date = Date(1, 1, 2016)
        assertTrue(date.isLeapYear())
    }

    @Test
    fun isLeapYear_Returns_False_For_Divisible_By_100_But_Not_400() {
        val date = Date(1, 1, 1900)
        assertFalse(date.isLeapYear())
    }
}
