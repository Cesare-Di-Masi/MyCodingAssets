class Date(dayVal:Int,monthVal:Int,yearVal:Int) {

    init {
        require(monthVal in 1..12){"illegal monthVal"}
        when{
            monthVal==1||monthVal==3||monthVal==5||monthVal==7||monthVal==8||monthVal==10||monthVal==12-> require(dayVal in 1..31)
            monthVal==2&&yearVal%4==0-> require(dayVal in 1..29)
            monthVal==2-> require(dayVal in 1..28)
            else-> require(dayVal in 1..30)
        }
    }

    val year=yearVal

    fun isLeapYear():Boolean{
        return year%4==0
    }

}