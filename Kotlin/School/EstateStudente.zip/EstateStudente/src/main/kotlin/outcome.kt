enum class outcome {
    PROMOTED, POSTPONED, FAILED
}