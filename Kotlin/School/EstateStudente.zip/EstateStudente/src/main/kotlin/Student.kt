class Student(nameValue:String, surnameValue:String, votesValue:Array<Int>) {

    init {
        require(nameValue.isNotEmpty()&&nameValue.isNotBlank()){"nameValue is illegal"}
        require(surnameValue.isNotEmpty()&&surnameValue.isNotBlank()){"Surnamevalue is illegal"}
        for (i in votesValue)
            require(i in 0..10){"$i is illegal in voteValue"}
    }

    val name=nameValue
    val surname=surnameValue
    val votes=votesValue

    fun nInsufficiency():Int{
        var counter=0
        for (i in votes.indices){
            if (votes[i]<6)
                counter++
        }
        return counter
    }

    fun nMissingPoints():Int{
        var counter=0
        for (i in votes.indices){
            if (votes[i]<6)
                counter+=6-votes[i]
        }
        return counter
    }

    fun outcome():outcome{
        val insufficiency=nInsufficiency()
        return when{
            insufficiency==0-> outcome.PROMOTED
            insufficiency in 1..4&& nMissingPoints()<=5-> outcome.POSTPONED
            else-> outcome.FAILED
        }
    }

}