import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*

class StudentTest {

    @Test
    fun get_nameValue_Is_Illegal_Empty() {
        val arrayTest = Array<Int>(10) { 6 }
        assertThrows<IllegalArgumentException> { val test = Student("", "Snow", arrayTest) }
    }

    @Test
    fun get_nameValue_Is_Illegal_Blank() {
        val arrayTest = Array<Int>(10) { 6 }
        assertThrows<IllegalArgumentException> { val test = Student(" ", "Snow", arrayTest) }
    }

    @Test
    fun get_surnameValue_Is_Illegal_Empty() {
        val arrayTest = Array<Int>(10) { 6 }
        assertThrows<IllegalArgumentException> { val test = Student("John", "", arrayTest) }
    }

    @Test
    fun get_surnameValue_Is_Illegal_Blank() {
        val arrayTest = Array<Int>(10) { 6 }
        assertThrows<IllegalArgumentException> { val test = Student("John", " ", arrayTest) }
    }

    @Test
    fun get_votesValue_Is_Illegal_Negative() {
        val arrayTest = Array<Int>(10) { 6 }
        arrayTest[1]=-1
        assertThrows<IllegalArgumentException> { val test = Student("John", "Snow", arrayTest) }
    }

    @Test
    fun get_votesValue_Is_Illegal_OutOfBounds() {
        val arrayTest = Array<Int>(10) { 6 }
        arrayTest[1]=11
        assertThrows<IllegalArgumentException> { val test = Student("John", "Snow", arrayTest) }
    }

    @Test
    fun get_nameValue_Is_Legal() {
        val arrayTest = Array<Int>(10) { 6 }
        assertDoesNotThrow { val test = Student("John", "Snow", arrayTest) }
    }

    @Test
    fun get_surnameValue_Is_Legal() {
        val arrayTest = Array<Int>(10) { 6 }
        assertDoesNotThrow { val test = Student("John", "Snow", arrayTest) }
    }

    @Test
    fun get_votesValue_Is_Legal() {
        val arrayTest = Array<Int>(10) { 6 }
        assertDoesNotThrow { val test = Student("John", "Snow", arrayTest) }
    }

    @Test
    fun nInsufficiency_Is_Correct_0() {
        val arrayTest = Array<Int>(10) { 6 }
        val test = Student("John", "Snow", arrayTest)
        assertEquals(0, test.nInsufficiency())
    }

    @Test
    fun nInsufficiency_Is_Correct_1() {
        val arrayTest = Array<Int>(10) { 6 }
        arrayTest[1]=5
        val test = Student("John", "Snow", arrayTest)
        assertEquals(1, test.nInsufficiency())
    }

    @Test
    fun nMissingPoints_Is_Correct_0() {
        val arrayTest = Array<Int>(10) { 6 }
        val test = Student("John", "Snow", arrayTest)
        assertEquals(0,test.nMissingPoints())
    }

    @Test
    fun nMissingPoints_Is_Correct_1() {
        val arrayTest = Array<Int>(10) { 6 }
        arrayTest[1]=5
        val test = Student("John", "Snow", arrayTest)
        assertEquals(1,test.nMissingPoints())
    }

    @Test
    fun outcome_Is_Correct_PROMOTED() {
        val arrayTest = Array<Int>(10) { 6 }
        val test = Student("John", "Snow", arrayTest)
        assertEquals(outcome.PROMOTED, test.outcome())
    }

    @Test
    fun outcome_Is_Correct_POSTPONED() {
        val arrayTest = Array<Int>(10) { 6 }
        arrayTest[1]=5
        val test = Student("John", "Snow", arrayTest)
        assertEquals(outcome.POSTPONED, test.outcome())
    }

    @Test
    fun outcome_Is_Correct_FAILED_nInsufficiency() {
        val arrayTest = Array<Int>(10) { 6 }
        arrayTest[0] = 5
        arrayTest[1] = 5
        arrayTest[2] = 5
        arrayTest[3] = 5
        arrayTest[4] = 5
        val test = Student("John", "Snow", arrayTest)
        assertEquals(outcome.FAILED, test.outcome())
    }

    @Test
    fun outcome_Is_Correct_FAILED_nPoints() {
        val arrayTest = Array<Int>(10) { 6 }
        arrayTest[0] = 1
        arrayTest[1] = 3
        val test = Student("John", "Snow", arrayTest)
        assertEquals(outcome.FAILED, test.outcome())
    }
}