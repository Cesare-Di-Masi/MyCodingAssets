enum class smartphoneType {
    MINI,NORMAL, MAXI
}