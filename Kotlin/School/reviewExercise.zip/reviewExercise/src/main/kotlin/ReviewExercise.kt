class ReviewExercise(brandValue:String,modelValue:String, launchPriceValue:Double, numThumbsValue:Double,ramValue:Int,touchScreenValue:Boolean){

    init {
        require(brandValue.isNotEmpty()&&brandValue.isNotBlank()){"illegal brand"}
        require(modelValue.isNotEmpty()&&modelValue.isNotBlank()){"illegal model"}
        require(launchPriceValue>0.0){"illegal launch price"}
        require(numThumbsValue>0.0){"illegal thumbs number"}
        require(ramValue>0.0){"illegal thumbs number"}
    }

    private var brand:String=brandValue
        set(value) {

            field=value
        }

    private var model:String=modelValue
        set(value) {
            require(value.isNotEmpty()&&value.isNotBlank()){"illegal model"}
            field=value
        }

    private var launchPrice:Double=launchPriceValue
        set(value) {
            require(value>0.0){"illegal launch price"}
            field=value
        }

    private var numThumbs:Double=numThumbsValue

        set(value) {
            require(value>0.0){"illegal thumbs number"}
            field=value
        }

    private var ram:Int=ramValue
        set(value) {
            require(value>0){"illegal ram"}
            field=value
        }

    private var touchScreen:Boolean=touchScreenValue
        set(value) {
            field=value
        }

    fun getPriceRange():priceRange{
        return when{
            launchPrice>500-> priceRange.HIGH
            launchPrice>200&&launchPrice<500-> priceRange.MID
            else-> priceRange.LOW
        }
    }

    fun getSmartphoneType():smartphoneType{
        return when{
            numThumbs>7.0-> smartphoneType.MAXI
            numThumbs>5.0&&numThumbs<7.0-> smartphoneType.NORMAL
            else-> smartphoneType.MINI
        }
    }


}