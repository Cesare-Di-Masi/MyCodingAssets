enum class priceRange {
    HIGH, MID, LOW
}