import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*

class ReviewExerciseTest {

    @Test
    fun brandValue_Is_Illegal_IsEmpty(){
        assertThrows<IllegalArgumentException> { val reviewTest=ReviewExercise("","1",12.0,8.0, 8,true) }
    }

    @Test
    fun brandValue_Is_Illegal_IsBlank(){
        assertThrows<IllegalArgumentException> { val reviewTest=ReviewExercise(" ","1",12.0,8.0, 8,true) }
    }

    @Test
    fun modelValue_Is_Illegal_IsEmpty(){
        assertThrows<IllegalArgumentException> { val reviewTest=ReviewExercise("Pear","",12.0,8.0, 8,true) }
    }

    @Test
    fun modelValue_Is_Illegal_IsBlank(){
        assertThrows<IllegalArgumentException> { val reviewTest=ReviewExercise("Pear"," ",12.0,8.0, 8,true) }
    }

    @Test
    fun launchPriceValue_Is_Illegal(){
        assertThrows<IllegalArgumentException> { val reviewTest=ReviewExercise("Pear","1",-12.0,8.0, 8,true) }
    }

    @Test
    fun numThumbsValue_Is_Illegal(){
        assertThrows<IllegalArgumentException> { val reviewTest=ReviewExercise("Pear","1",12.0,-8.0, 8,true) }
    }

    @Test
    fun ramValue_Is_Illegal(){
        assertThrows<IllegalArgumentException> { val reviewTest=ReviewExercise("Pear","1",12.0,8.0, -8,true) }
    }

    @Test
    fun brandValue_Is_Legal(){
        assertDoesNotThrow { val reviewTest=ReviewExercise("Pear","1",12.0,8.0, 8,true) }
    }

    @Test
    fun modelValue_Is_Legal(){
        assertDoesNotThrow { val reviewTest=ReviewExercise("Pear","1",12.0,8.0, 8,true) }
    }

    @Test
    fun launchPriceValue_Is_Legal(){
        assertDoesNotThrow { val reviewTest=ReviewExercise("Pear","1",12.0,8.0, 8,true) }
    }

    @Test
    fun numThumbsValue_Is_Legal(){
        assertDoesNotThrow { val reviewTest=ReviewExercise("Pear","1",12.0,8.0, 8,true) }
    }

    @Test
    fun ramValue_Is_Legal(){
        assertDoesNotThrow { val reviewTest=ReviewExercise("Pear","1",12.0,8.0, 8,true) }
    }

    @Test
    fun getPriceRange_Is_Correct_Low() {
        val reviewTest=ReviewExercise("Pear","1",120.0,8.0, 8,true)
        assertEquals(priceRange.LOW, reviewTest.getPriceRange())
    }

    @Test
    fun getPriceRange_Is_Correct_Mid() {
        val reviewTest=ReviewExercise("Pear","1",220.0,8.0, 8,true)
        assertEquals(priceRange.MID, reviewTest.getPriceRange())
    }

    @Test
    fun getPriceRange_Is_Correct_High() {
        val reviewTest=ReviewExercise("Pear","1",520.0,8.0, 8,true)
        assertEquals(priceRange.HIGH, reviewTest.getPriceRange())
    }

    @Test
    fun getSmartphoneType_Is_Correct_Mini() {
        val reviewTest=ReviewExercise("Pear","1",520.0,4.0, 8,true)
        assertEquals(smartphoneType.MINI,reviewTest.getSmartphoneType())
    }

    @Test
    fun getSmartphoneType_Is_Correct_Normal() {
        val reviewTest=ReviewExercise("Pear","1",520.0,6.0, 8,true)
        assertEquals(smartphoneType.NORMAL,reviewTest.getSmartphoneType())
    }

    @Test
    fun getSmartphoneType_Is_Correct_Maxi() {
        val reviewTest=ReviewExercise("Pear","1",520.0,8.0, 8,true)
        assertEquals(smartphoneType.MAXI,reviewTest.getSmartphoneType())
    }
}