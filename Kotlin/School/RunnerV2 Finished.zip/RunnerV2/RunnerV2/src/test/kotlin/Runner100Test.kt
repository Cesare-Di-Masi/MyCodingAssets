import org.junit.jupiter.api.Test
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.assertThrows


class Runner100Test {

    @Test
    fun setName_Blank(){
        assertThrows<IllegalArgumentException>{Runner100(" ")}
    }

    @Test
    fun setName_Empty(){
        assertThrows<IllegalArgumentException>{Runner100("")}
    }

    @Test
    fun badResult_resultsWithAllZero() {
        val runner = Runner100("nome")
        assertEquals(null,runner.badResult())
    }

    @Test
    fun badResult_resultsWithValues() {
        val runner = Runner100("nome")
        for(i in runner.results.indices)
        {
            runner.results[i]=i
        }
        assertEquals(9,runner.badResult())
    }


    @Test
    fun besResult_resultsWithAllZero() {
        val runner = Runner100("nome")
        assertEquals(null,runner.bestResult())
    }


    @Test
    fun bestResult_resultsWithValues() {
        val runner = Runner100("nome")
        for(i in runner.results.indices)
        {
            runner.results[i]=i
        }
        assertEquals(1,runner.bestResult())
    }


    @Test
    fun addResult_resultsWithZero()
    {
        val runner = Runner100("nome")
        for(i in runner.results.indices)
        {
            runner.results[i]=i
        }
        assertEquals(true, runner.addResult(10))
    }


    @Test
    fun addResult_resultsNotBetterThanBad()
    {
        val runner = Runner100("nome")
        for(i in runner.results.indices)
        {
            runner.results[i]=i+1
        }
        assertEquals(false, runner.addResult(10))
    }


    @Test
    fun addResult_resultsBetterThanBad()
    {
        val runner = Runner100("nome")
        for(i in runner.results.indices)
        {
            runner.results[i]=i+1
        }
        assertEquals(true, runner.addResult(8))
    }

    @Test
    fun modifyResult_NegativePos() {
        val runner = Runner100("nome")
        assertThrows<IllegalArgumentException> { runner.modifyResult(-8,3200) }
    }

    @Test
    fun modifyResult_ZeroPos() {
        val runner = Runner100("nome")
        assertDoesNotThrow { runner.modifyResult(0,3200) }
    }

    @Test
    fun modifyResult_NegativeResults() {
        val runner = Runner100("nome")
        assertThrows<IllegalArgumentException> { runner.modifyResult(3,-3200) }
    }

    @Test
    fun modifyResult_ZeroResults() {
        val runner = Runner100("nome")
        assertThrows<IllegalArgumentException> { runner.modifyResult(3,0) }
    }

    @Test
    fun reDoArray_NegativeParameters() {
        val array=Array<Int>(10){-10}
        val runner = Runner100("nome")
        assertThrows<IllegalArgumentException> { runner.reDoArray(array) }
    }

    @Test
    fun averageResults() {
        val runner = Runner100("nome")
        runner.addResult(100)
        runner.addResult(150)
        runner.addResult(75)

        assertEquals(108,runner.averageResults())
    }

    @Test
    fun findAverageWaste_IsCorrect(){
        val runner=Runner100("name")
        runner.addResult(2)
        runner.addResult(6)
        runner.addResult(4)
        assertEquals(2,runner.findAverageResultWaste())
    }

}

