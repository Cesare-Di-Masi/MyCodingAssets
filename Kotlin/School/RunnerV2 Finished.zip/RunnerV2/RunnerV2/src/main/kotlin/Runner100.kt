class Runner100(val name:String) {
    val results:Array<Int>
    init {
        require(name.isNotBlank()&& name.isNotEmpty()){"Illegal set for name"}
        results = Array(10){0}
        }

    fun bestResult():Int?
    {
        var best = Int.MAX_VALUE
        for(res in results)
        {
            if(res<best && res >0)
            {
                best = res
            }
        }
        if(best == Int.MAX_VALUE)return null
        return best
    }
    fun badResult():Int?
    {
        var bad = results[0]
        for(res in results) {
            if (res > bad) {
                bad = res
            }
        }
        if(bad==0)return null
        return bad
    }
    fun addResult(result:Int):Boolean
    {
        require(result>0){"tempo non corretto"}
        var add = false
        val pos = findResult(0)

        if(pos!=null) {
            results[pos] = result
            add = true
        }
        else{
            val bad = badResult()!!.toInt()
            if(result<bad)
            {
                val pos = findResult(bad)!!.toInt()
                results[pos]=result
                add = true
            }
        }
        return add
    }
    private fun findResult(result:Int):Int?
    {
        for(i in results.indices)
        {
            if(results[i] == result)
                return i
        }
        return null
    }

    fun modifyResult(pos:Int,result:Int){
        require(pos in 0..9){"position not acceptable"}
        require(result>0){"Illegal result value set"}
        results[pos]=result
    }

    fun reDoArray(arrayToCopy:Array<Int>){
        require(arrayToCopy.size==10){"array size is not acceptable"}
        for (i in arrayToCopy)
            require(i>0){"an array parameters is Illegal"}

        for (i in 0..9)
            results[i]=arrayToCopy[i]
    }

    fun averageResults():Int{
        var counter=0
        var sum=0
        for(i in results.indices){
            if (results[i]!=0) {
                sum += results[i]
                counter++
            }
        }
        return sum/counter
    }

    fun findAverageResultWaste(){
        val averageResult=averageResults()
        val averageWaste=results
        for (i in averageWaste.indices){
            if (averageWaste[i]!=0) {
                averageWaste[i] -= averageResult
            }
        }
    }
}