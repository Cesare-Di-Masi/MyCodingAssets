fun main() {
    val n=Runner100("name")
    n.addResult(2)
    n.addResult(6)
    n.addResult(4)
    n.findAverageResultWaste()


}