import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*

class SoccerPlayerTest {

    @Test
    fun soccerPlayerNumber_Is_Illegal(){
        val min=Array<Int>(10){0}
        val goal=Array<Int>(10){0}
        assertThrows<IllegalArgumentException> { val soccerPlayerTest=SoccerPlayer(-1,goal,min) }
    }

    @Test
    fun totGoalScored_Is_Illegal(){
        val min=Array<Int>(10){0}
        val goal=Array<Int>(10){-1}
        assertThrows<IllegalArgumentException> { val soccerPlayerTest=SoccerPlayer(1,goal,min) }
    }

    @Test
    fun totMinPlayed_Is_Illegal(){
        val min=Array<Int>(10){-1}
        val goal=Array<Int>(10){1}
        assertThrows<IllegalArgumentException> { val soccerPlayerTest=SoccerPlayer(1,goal,min) }
    }

    @Test
    fun soccerPlayerNumber_Is_Legal() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        assertDoesNotThrow { val soccerPlayerTest = SoccerPlayer(1, goal, min) }
    }

    @Test
    fun totGoalScored_Is_Legal() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        assertDoesNotThrow { val soccerPlayerTest = SoccerPlayer(1, goal, min) }
    }

    @Test
    fun totMinPlayed_Is_Legal() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        assertDoesNotThrow { val soccerPlayerTest = SoccerPlayer(1, goal, min) }
    }

    @Test
    fun addMinutes_Position_Is_Illegal_Negative() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertThrows<IllegalArgumentException> { soccerPlayerTest.addMinutes(2,-1) }
    }

    @Test
    fun addMinutes_Position_Is_Illegal_toBig() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertThrows<IllegalArgumentException> { soccerPlayerTest.addMinutes(2,11) }
    }

    @Test
    fun addMinutes_numberOfMinutes_Is_Illegal_Negative() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertThrows<IllegalArgumentException> { soccerPlayerTest.addMinutes(-1,1) }
    }

    @Test
    fun addMinutes_Position_Is_legal() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertDoesNotThrow{ soccerPlayerTest.addMinutes(2,1) }
    }

    @Test
    fun addMinutes_numberOfMinutes_Is_legal() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertDoesNotThrow{ soccerPlayerTest.addMinutes(2,1) }
    }

    @Test
    fun addMinutes_Is_Correct(){
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val expected=Array<Int>(10){1}
        expected[0]=2
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        soccerPlayerTest.addMinutes(2,1)
        assertArrayEquals(expected,soccerPlayerTest.totMinPlayed)
    }

    @Test
    fun addGoal_Position_Is_Illegal_Negative() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertThrows<IllegalArgumentException> { soccerPlayerTest.addGoal(2,-1) }
    }

    @Test
    fun addGoal_Position_Is_Illegal_toBig() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertThrows<IllegalArgumentException> { soccerPlayerTest.addGoal(2,11) }
    }

    @Test
    fun addGoal_numberOfMinutes_Is_Illegal_Negative() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertThrows<IllegalArgumentException> { soccerPlayerTest.addGoal(-1,1) }
    }

    @Test
    fun addGoal_Position_Is_legal() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertDoesNotThrow{ soccerPlayerTest.addGoal(2,1) }
    }

    @Test
    fun addGoal_numberOfMinutes_Is_legal() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertDoesNotThrow{ soccerPlayerTest.addGoal(2,1) }
    }

    @Test
    fun addGoal_Is_Correct(){
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val expected=Array<Int>(10){1}
        expected[0]=2
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        soccerPlayerTest.addGoal(2,1)
        assertArrayEquals(expected,soccerPlayerTest.totGoalScored)
    }

    @Test
    fun totGoalScoredAllGames_Is_Correct() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertEquals(10.0,soccerPlayerTest.totGoalScoredAllGames())
    }

    @Test
    fun totMinPlayedAllGames_Is_Correct() {
        val min = Array<Int>(10) { 1 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertEquals(10.0,soccerPlayerTest.totMinPlayedAllGames())
    }

    @Test
    fun averageGoalScored_Is_Correct() {
        val min = Array<Int>(10) { 2 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        assertEquals(2.0,soccerPlayerTest.averageGoalScored())
    }

    @Test
    fun bestGame() {
        val min = Array<Int>(10) { 2 }
        val goal = Array<Int>(10) { 1 }
        val soccerPlayerTest = SoccerPlayer(1, goal, min)
        soccerPlayerTest.addGoal(10,10)
        assertEquals(10,soccerPlayerTest.bestGame())
    }
}