class SoccerPlayer(playerNumber:Int, totGoalScoredValue:Array<Int>, totMinPlayedValue:Array<Int>) {

    init {
        require(playerNumber>0){"illegal player number"}
        for (i in totGoalScoredValue)
            require(i>=0){"Illegal amount of goal scored"}
        for (i in totMinPlayedValue)
            require(i>=0){"illegal amount of min played"}
    }

    val totGoalScored=totGoalScoredValue
    val totMinPlayed=totMinPlayedValue

    fun addMinutes(numberOfMinutes:Int,position:Int){
        require(numberOfMinutes>0){"illegal minutes"}
        require(position>0&&position<=totMinPlayed.size){"illegal position"}
        totMinPlayed[position-1]=numberOfMinutes
    }

    fun addGoal(numberOfScore:Int, position:Int){
        require(numberOfScore>0){"illegal scores"}
        require(position>0&&position<=totGoalScored.size){"illegal position"}
        if (totMinPlayed[position-1]!=0)
            totGoalScored[position-1]=numberOfScore
    }

    fun totGoalScoredAllGames():Double{
        var counterG=0.0
        for (i in totGoalScored)
            counterG+=i
        return counterG
    }

    fun totMinPlayedAllGames():Double{
        var counterM=0.0
        for (i in totMinPlayed)
            counterM+=i
        return counterM
    }

    fun averageGoalScored():Double{
        return totMinPlayedAllGames()/totGoalScoredAllGames()
    }

    fun bestGame():Int{
        var best=Int.MIN_VALUE
        var goal=Int.MIN_VALUE
        for(i in totGoalScored.indices){
            if (goal<totGoalScored[i]) {
                best = i
                goal = totGoalScored[i]
            }
        }
        return best+1
    }

}