fun main(args: Array<String>) {
    val cells=CellReproduction(60,5)
    println(cells.cellReproduction())
}