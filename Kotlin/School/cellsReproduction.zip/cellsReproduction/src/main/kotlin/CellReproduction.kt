import kotlin.math.pow

class CellReproduction (daysValue:Int, daysForGrowingValue:Int){
    init {
        require(daysValue>=0){"number must be natural"}
        require(daysForGrowingValue>0){"number must be natural and more than 0"}
    }
    val days=daysValue
    val daysForGrowing=daysForGrowingValue

    fun cellReproduction():Double{

        val totReproductionDays:Double=days/daysForGrowing.toDouble()
        val totCells: Double = 2.0.pow(totReproductionDays)
        return totCells
    }

}