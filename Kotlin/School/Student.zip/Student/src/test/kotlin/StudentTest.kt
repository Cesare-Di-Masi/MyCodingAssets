import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.*

class StudentTest(){

    @Test
    fun nameValue_IsIllegal_IsBlank(){
        val average=Array<Double>(10){1.0}
        assertThrows<IllegalArgumentException> { val studentTest=Student(" ",true,average) }
    }

    @Test
    fun nameValue_IsIllegal_IsEmpty(){
        val average=Array<Double>(10){1.0}
        assertThrows<IllegalArgumentException> { val studentTest=Student("",true,average) }
    }

    @Test
    fun subjectsGradesValue_IsIllegal_IsNegative(){
        val average=Array<Double>(10){-1.0}
        assertThrows<IllegalArgumentException> { val studentTest=Student("John",true,average) }
    }

    @Test
    fun subjectsGradesValue_IsIllegal_IsOutOfBounds(){
        val average=Array<Double>(10){11.0}
        assertThrows<IllegalArgumentException> { val studentTest=Student("John",true,average) }
    }

    @Test
    fun nameValue_IsLegal(){
        val average=Array<Double>(10){1.0}
        assertDoesNotThrow{val studentTest=Student("John",true,average)}
    }

    @Test
    fun subjectsGradesValue_IsLegal(){
        val average=Array<Double>(10){1.0}
        assertDoesNotThrow{val studentTest=Student("John",true,average)}
    }

    @Test
    fun modifyAGrade_newGrade_IsIllegal_Negative(){
        val average=Array<Double>(10){1.0}
        val studentTest=Student("John",true,average)
        assertThrows<IllegalArgumentException> { studentTest.modifyAGrade(-1.0,1) }
    }

    @Test
    fun modifyAGrade_newGrade_IsIllegal_OutOfBounds(){
        val average=Array<Double>(10){1.0}
        val studentTest=Student("John",true,average)
        assertThrows<IllegalArgumentException> { studentTest.modifyAGrade(11.0,1) }
    }

    @Test
    fun modifyAGrade_position_IsIllegal_Negative(){
        val average=Array<Double>(10){1.0}
        val studentTest=Student("John",true,average)
        assertThrows<IllegalArgumentException> { studentTest.modifyAGrade(2.0,-1) }
    }

    @Test
    fun modifyAGrade_position_IsIllegal_OutOfBounds(){
        val average=Array<Double>(10){1.0}
        val studentTest=Student("John",true,average)
        assertThrows<IllegalArgumentException> { studentTest.modifyAGrade(2.0,10) }
    }

    @Test
    fun modifyAGrade_newGrade_IsLegal(){
        val average=Array<Double>(10){1.0}
        val studentTest=Student("John",true,average)
        assertDoesNotThrow{studentTest.modifyAGrade(2.0,1)}
    }

    @Test
    fun modifyAGrade_position_IsLegal(){
        val average=Array<Double>(10){1.0}
        val studentTest=Student("John",true,average)
        assertDoesNotThrow{studentTest.modifyAGrade(2.0,1)}
    }

    @Test
    fun modifyAGrade_IsCorrect(){
        val average=Array<Double>(10){1.0}
        val studentTest=Student("John",true,average)
        studentTest.modifyAGrade(2.0,1)
        assertEquals(2.0,studentTest.subjectsGrades[1])
    }

    @Test
    fun finalDegree_IsCorrect_Excess(){
        val average=Array<Double>(10){1.75}
        val studentTest=Student("John",true,average)
        val expectedArray=Array<Int>(10){2}
        assertArrayEquals(expectedArray,studentTest.finalDegree())
    }

    @Test
    fun finalDegree_IsCorrect_Down(){
        val average=Array<Double>(10){1.5}
        val studentTest=Student("John",true,average)
        val expectedArray=Array<Int>(10){1}
        assertArrayEquals(expectedArray,studentTest.finalDegree())
    }

    @Test
    fun finalOutcome_IsCorrect_Promoted(){
        val average=Array<Double>(10){6.0}
        val studentTest=Student("John",true,average)
        assertEquals(1,studentTest.finalOutcome())
    }

    @Test
    fun finalOutcome_IsCorrect_Postponed(){
        val average=Array<Double>(10){6.0}
        val studentTest=Student("John",true,average)
        studentTest.modifyAGrade(4.0,0)
        assertEquals(2,studentTest.finalOutcome())
    }

    @Test
    fun finalOutcome_IsCorrect_Failed_NumberInsufficiency_IsInSecond_True(){
        val average=Array<Double>(10){6.0}
        val studentTest=Student("John",true,average)
        studentTest.modifyAGrade(4.0,0)
        studentTest.modifyAGrade(4.0,1)
        studentTest.modifyAGrade(4.0,2)
        studentTest.modifyAGrade(4.0,3)
        assertEquals(3,studentTest.finalOutcome())
    }

    @Test
    fun finalOutcome_IsCorrect_Failed_NumberOfPoints_IsInSecond_True(){
        val average=Array<Double>(10){6.0}
        val studentTest=Student("John",true,average)
        studentTest.modifyAGrade(2.0,0)
        studentTest.modifyAGrade(4.0,1)
        assertEquals(3,studentTest.finalOutcome())
    }

    @Test
    fun finalOutcome_IsCorrect_Failed_NumberInsufficiency_IsInSecond_False(){
        val average=Array<Double>(10){6.0}
        val studentTest=Student("John",false,average)
        studentTest.modifyAGrade(4.0,0)
        studentTest.modifyAGrade(4.0,1)
        studentTest.modifyAGrade(4.0,2)
        studentTest.modifyAGrade(4.0,3)
        assertEquals(3,studentTest.finalOutcome())
    }

    @Test
    fun finalOutcome_IsCorrect_Failed_NumberOfPoints_IsInSecond_False(){
        val average=Array<Double>(10){6.0}
        val studentTest=Student("John",false,average)
        studentTest.modifyAGrade(2.0,0)
        studentTest.modifyAGrade(5.0,1)
        assertEquals(3,studentTest.finalOutcome())
    }

}