class Student(nameValue:String,isInSecondClassValue:Boolean,subjectsGradesValue:Array<Double>) {

    init {
        require(nameValue.isNotBlank()&&nameValue.isNotEmpty()){"name is illegal"}
        for (i in subjectsGradesValue.indices)
            require(subjectsGradesValue[i]>0.0&&subjectsGradesValue[i]<=10.0){"illegal grades, position is $i"}

    }

    val name=nameValue
    val subjectsGrades=subjectsGradesValue
    val isInSecondClass=isInSecondClassValue

    fun modifyAGrade(newGrade:Double,position:Int){
        require(newGrade>0.0&&newGrade<=10.0)
        require(position>=0&&position<subjectsGrades.size)
        subjectsGrades[position]=newGrade
    }

    fun finalDegree():Array<Int>{
        val finalDegree=Array<Int>(subjectsGrades.size){0}
        for (i in subjectsGrades.indices){
            if (subjectsGrades[i]%1<0.75)
                finalDegree[i]=subjectsGrades[i].toInt()
            else
                finalDegree[i]=subjectsGrades[i].toInt()+1
        }
        return finalDegree
    }

    fun finalOutcome():Int{
        val finalDegree=finalDegree()
        var counterInsufficiency=0
        var totalPointForSufficiency=0
        for (i in finalDegree){

            if (i<6) {
                counterInsufficiency++
                totalPointForSufficiency+=6-i
            }
        }
        return when{
            counterInsufficiency==0-> 1
            counterInsufficiency in 1..3&&totalPointForSufficiency<=4-> 2
            counterInsufficiency in 1..3&&totalPointForSufficiency<=5&&isInSecondClass-> 2
            counterInsufficiency>3&&totalPointForSufficiency>4&&!isInSecondClass-> 3
            else->3
        }

    }

}