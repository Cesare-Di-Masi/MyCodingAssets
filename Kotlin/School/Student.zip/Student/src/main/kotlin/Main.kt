fun main() {
    val average=Array<Double>(10){6.0}
    val studentTest=Student("John",true,average)
    studentTest.modifyAGrade(2.0,0)
    studentTest.modifyAGrade(5.0,1)
    println(studentTest.finalOutcome())
}