import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import kotlin.IllegalArgumentException


class TrafficLightTest {



}