class TrafficLight( lightTimeValue:Int,hourShuttingDownValue:Int,minuteShuttingDownValue:Int, hourPowerOnValue:Int, minutePowerOnValue:Int) {

    init {

        require(lightTimeValue>0){"lightTime must greater than 0"}
        require(hourPowerOnValue in 0..23){"hoursPowerOn must be between 0 and 23"}
        require(hourShuttingDownValue in 0..23){"hoursShuttingDown must be between 0 and 23"}
        require(minutePowerOnValue in 0..60){"minutesPowerOn must be between 0 and 60"}
        require(minuteShuttingDownValue in 0..60){"minutesShuttingDown must be between 0 and 60"}
    }

    private val lightTime=lightTimeValue
    private val greenTime=lightTime
    private val orangeTime=lightTime/2
    private val redTime=lightTime
    private val lightCycleTime=greenTime+orangeTime+redTime
    private val hourShuttingDown=hourShuttingDownValue
    private val minuteShuttingDown=minuteShuttingDownValue
    private val hourTimePowerOn=hourPowerOnValue
    private val minutePowerOn=minutePowerOnValue

    enum class lightColour{
        Red,Orange,Green
    }


    fun findLight(hoursValue:Int,minutesValue:Int,secondsValue:Int):lightColour {

        require(hoursValue in 0..23) { "hours must be between 0 and 23" }
        require(minutesValue in 0..59) { "minutes must be between 0 and 59" }
        require(secondsValue in 0..59) { "seconds must be between 0 and 59" }

        val timeInSeconds = hoursValue * 3600 + minutesValue * 60 + secondsValue
        val timePowerOnInSeconds = hourTimePowerOn * 3600 + minutePowerOn * 60
        val timePowerOffInSeconds = hourShuttingDown * 3600 + minuteShuttingDown * 60

        return when {
            timeInSeconds >= timePowerOffInSeconds || timeInSeconds <= timePowerOnInSeconds -> lightColour.Orange
            timeInSeconds % lightCycleTime < greenTime -> lightColour.Green
            timeInSeconds % lightCycleTime < greenTime + orangeTime -> lightColour.Orange
            else -> lightColour.Red
        }

    }

}