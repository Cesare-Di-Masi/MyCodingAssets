fun main(args: Array<String>) {

    val trafficLight=TrafficLight(60,22,0,4,0)
    println(trafficLight.findLight(4,0,1))


}