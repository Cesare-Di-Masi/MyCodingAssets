fun main(args: Array<String>) {

    val trafficLight=TrafficLight(60,4,0,22,0)
    trafficLight.findLight(1,1,1)
    println(trafficLight)


}