class TrafficLight( lightTimeValue:Int,hourShuttingDownValue:Int,minuteShuttingDownValue:Int, hourPowerOnValue:Int, minutePowerOnValue:Int) {

    init {

        require(lightTimeValue>0){"lightTime must greater than 0"}
        require(hourPowerOnValue in 0..23){"hoursPowerOn must be between 0 and 23"}
        require(hourShuttingDownValue in 0..23){"hoursShuttingDown must be between 0 and 23"}
        require(minutePowerOnValue in 0..59){"minutesPowerOn must be between 0 and 59"}
        require(minuteShuttingDownValue in 0..59){"minutesShuttingDown must be between 0 and 59"}
    }

    private val lightTime=lightTimeValue
    private val greenTime=lightTime
    private val orangeTime=lightTime/2
    private val redTime=lightTime
    private val lightCycleTime=greenTime+orangeTime+redTime
    private val hourShuttingDown=hourShuttingDownValue
    private val minuteShuttingDown=minuteShuttingDownValue
    private val hourPowerOn=hourPowerOnValue
    private val minutePowerOn=minutePowerOnValue
    private var isLightOn=true
    private var lightColour=TrafficLight.lightColourValue.Orange

    enum class lightColourValue{
        Red,Orange,Green
    }


    fun findLight(hoursValue:Int,minutesValue:Int,secondsValue:Int) {

        val minorTimeInSeconds=0
        val greaterTimeInSeconds=0

        if (hourShuttingDown>hourPowerOn){
            val minorTimeInSeconds = hourPowerOn * 3600 + minutePowerOn * 60
            val greaterTimeInSeconds = hourShuttingDown * 3600 + minuteShuttingDown * 60
        }else{
            val minorTimeInSeconds = hourShuttingDown * 3600 + minuteShuttingDown * 60
            val greaterTimeInSeconds = hourPowerOn * 3600 + minutePowerOn * 60
        }

        require(hoursValue in 0..23) { "hours must be between 0 and 23" }
        require(minutesValue in 0..59) { "minutes must be between 0 and 59" }
        require(secondsValue in 0..59) { "seconds must be between 0 and 59" }

        val timeInSeconds = hoursValue * 3600 + minutesValue * 60 + secondsValue
        

        return when {
            timeInSeconds >= greaterTimeInSeconds || timeInSeconds <= minorTimeInSeconds -> lightColour=lightColourValue.Orange
            timeInSeconds >= greaterTimeInSeconds || timeInSeconds <= minorTimeInSeconds -> isLightOn=false
            timeInSeconds % lightCycleTime < greenTime -> lightColour=lightColourValue.Green
            timeInSeconds % lightCycleTime < greenTime + orangeTime -> lightColour=lightColourValue.Orange
            else -> lightColour=lightColourValue.Red
        }

    }

    override fun toString(): String {
        return "Traffic Light Colour= $lightColour. The traffic Light is on= $isLightOn. ||" +
                "time shutting Down $hourShuttingDown.$minuteShuttingDown||" +
                "time powering on  $hourPowerOn.$minuteShuttingDown"
    }

}