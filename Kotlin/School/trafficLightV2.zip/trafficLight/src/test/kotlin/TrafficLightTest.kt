import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import kotlin.IllegalArgumentException


class TrafficLightTest {

    @Test
    fun lightTimeValueIsNegative(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(-1,23,0,4,0) }
    }

    @Test
    fun lightTimeValueIsZero(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(0,23,0,4,0) }
    }

    @Test
    fun lighTimeValueIsCorrect(){
        assertDoesNotThrow { val lightTest=TrafficLight(60,23,0,4,0) }
    }

    @Test
    fun hourPowerOnValueIsNegative(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,0,-1,0) }
    }

    @Test
    fun hourPowerOnValueIsGreaterThan23(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,0,24,0) }
    }

    @Test
    fun hourPowerOnValueIsCorrect(){
        assertDoesNotThrow { val lightTest=TrafficLight(60,23,0,4,0) }
    }

    @Test
    fun hourShuttingDownValueIsNegative(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,-1,0,4,0) }
    }

    @Test
    fun hourShuttingDownValueIsGreaterThan23(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,24,0,24,0) }
    }

    @Test
    fun hourShuttingDownValueIsCorrect(){
        assertDoesNotThrow { val lightTest=TrafficLight(60,23,0,4,0) }
    }

    @Test
    fun minutePowerOnIsNegative(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,0,4,-1) }
    }

    @Test
    fun minutePowerOnIsGreaterThan59(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,0,4,60) }
    }

    @Test
    fun minutePowerOnValueIsCorrect(){
        assertDoesNotThrow { val lightTest=TrafficLight(60,23,0,4,0) }
    }

    @Test
    fun minuteShuttingDownValueIsNegative(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,-1,4,0) }
    }

    @Test
    fun minuteShuttingDownValueIsGreaterThan59(){
        assertThrows<IllegalArgumentException> { val lightTest=TrafficLight(60,23,60,4,0) }
    }

    @Test
    fun minuteShuttingDownValueIsCorrect(){
        assertDoesNotThrow { val lightTest=TrafficLight(60,23,0,4,0) }
    }

    @Test
    fun findLightHoursValueIsNegative(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLight(-1,0,0) }
    }

    @Test
    fun findLightHoursValueIsGreaterThan23(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLight(24,0,0) }
    }

    @Test
    fun findLightHoursValueValueIsCorrect(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertDoesNotThrow { lightTest.findLight(4,0,0) }
    }

    @Test
    fun findLightMinutesValueIsNegative(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLight(4,-1,0) }
    }

    @Test
    fun findLightMinutesValueIsGreaterThan59(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLight(4,60,0) }
    }

    @Test
    fun findLightMinutesValueValueIsCorrect(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertDoesNotThrow { lightTest.findLight(4,0,0) }
    }

    @Test
    fun findLightSecondsValueIsNegative(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLight(4,0,-1) }
    }

    @Test
    fun findLightSecondsValueIsGreaterThan59(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertThrows<IllegalArgumentException> { lightTest.findLight(4,0,60) }
    }

    @Test
    fun findLightSecondsValueValueIsCorrect(){
        val lightTest=TrafficLight(60,23,0,4,0)
        assertDoesNotThrow { lightTest.findLight(4,0,0) }
    }

}