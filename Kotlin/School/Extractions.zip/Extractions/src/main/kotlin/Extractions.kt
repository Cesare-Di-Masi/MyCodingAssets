import kotlin.math.*

class Extractions(minValue:Int, maxValue:Int) {
    val extractedNumbers:Array<Boolean>
    init {
        require(minValue< maxValue){"Illegal value"}
        extractedNumbers=Array(maxValue-minValue){false}
    }
    val min=minValue
    val max=maxValue

    fun addAValue(){
        var newValue=(min..max).random()
        var pos=newValue-min
        if (!extractedNumbers[pos])
            extractedNumbers[pos]=true
    }

    fun numberOfExtracted():Int{
        var counter=0
        for (i in extractedNumbers.indices){
            if (extractedNumbers[i])
                counter++
        }
        return counter
    }

    fun numberOfNotExtracted():Int{
        var counter=0
        for (i in extractedNumbers.indices){
            if (!extractedNumbers[i])
                counter++
        }
        return counter
    }

}