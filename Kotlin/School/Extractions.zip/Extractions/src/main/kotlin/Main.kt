
fun main(args: Array<String>) {

    val n=Extractions(2,8)
    n.addAValue()
    n.addAValue()
    n.addAValue()
    n.addAValue()
    n.addAValue()
    n.addAValue()
    n.addAValue()
    n.addAValue()
    println(n.numberOfExtracted())
    println(n.numberOfNotExtracted())

}