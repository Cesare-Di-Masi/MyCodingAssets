import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*


import org.junit.jupiter.api.Assertions.*

class TriangleTest {

    @Test
    fun getSide1IsIllegal() {
        assertThrows<IllegalArgumentException> { val triangleTest=Triangle(-1.0,2.0,3.0) }
    }

    @Test
    fun getSide2isIllegal() {
        assertThrows<IllegalArgumentException> { val triangleTest=Triangle(1.0,-2.0,3.0) }
    }

    @Test
    fun getSide3isIllegal() {
        assertThrows<IllegalArgumentException> { val triangleTest=Triangle(1.0,2.0,-3.0) }
    }

    @Test
    fun getTriangleTypeIsEquilateral() {
        val triangleTest=Triangle(3.0,3.0,3.0)
        assertEquals(EnumTriangle.Equilateral,triangleTest.triangleType)
    }

    @Test
    fun getTriangleTypeIsIsosceles() {
        val triangleTest=Triangle(2.0,3.0,3.0)
        assertEquals(EnumTriangle.Isosceles,triangleTest.triangleType)
    }

    @Test
    fun getTriangleTypeIsScalene() {
        val triangleTest=Triangle(1.0,2.0,3.0)
        assertEquals(EnumTriangle.Scalene,triangleTest.triangleType)
    }

    @Test
    fun calculatePerimeterIsCorrect() {
        val triangleTest=Triangle(1.0,2.0,3.0)
        assertEquals(6,6)
    }

    @Test
    fun isRight_True_triangleTypeIsIsosceles() {
        val triangleTest=Triangle(7.0,5.0,5.0)
        assertEquals(true,triangleTest.isRight())
    }

    @Test
    fun isRight_False_triangleTypeIsIsosceles() {
        val triangleTest=Triangle(8.0,5.0,5.0)
        assertEquals(false,triangleTest.isRight())
    }

    @Test
    fun isRight_True_triangleTypeIsScalene() {
        val triangleTest=Triangle(5.0,3.0,4.0)
        assertEquals(true,triangleTest.isRight())
    }

    @Test
    fun isRight_False_triangleTypeIsScalene() {
        val triangleTest=Triangle(6.0,3.0,4.0)
        assertEquals(false,triangleTest.isRight())
    }
}