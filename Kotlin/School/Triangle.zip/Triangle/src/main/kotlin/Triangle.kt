import kotlin.math.sqrt

class Triangle(side1Value:Double, side2Value:Double, side3Value:Double) {

    init {
        require(side1Value>0){"the sides must be a natural number"}
        require(side2Value>0){"the sides must be a natural number"}
        require(side3Value>0){"the sides must be a natural number"}

    }

    val side1=side1Value
    val side2=side2Value
    val side3=side3Value

    val triangleType:EnumTriangle
        get() {
        return if (side1 == side2 && side2 == side3) {
            EnumTriangle.Equilateral
        } else if (side1 == side2 || side2 == side3 || side1 == side3) {
            EnumTriangle.Isosceles
        } else {
            EnumTriangle.Scalene
        }
    }

    fun calculatePerimeter():Double{
        return side1+side2+side3
    }

    fun isRight(): Boolean {
        val maxSide:Double = when{
            side1>side2&&side1>side3-> side1
            side2>side3-> side2
            else-> side3
        }
        return when (maxSide) {
            side1 -> maxSide==sqrt(side2*side2+side3*side3)
            side2 -> maxSide==sqrt(side1*side1+side3*side3)
            side3 -> maxSide==sqrt(side1*side1+side2*side2)
            else-> false
        }
    }


}