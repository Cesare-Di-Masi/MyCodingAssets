import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.*

class BillTest {

    @Test
    fun quantityM3Val_Is_Illegal_Negative_Value() {
        assertThrows<IllegalArgumentException> { Bill(-50.0) }
    }

    @Test
    fun quantityM3Val_Is_Illegal_Zero_Value() {
        assertThrows<IllegalArgumentException> { Bill(0.0) }
    }

    @Test
    fun quantityM3Val_Is_Legal_Positive_Value() {
        assertDoesNotThrow { Bill(50.0) }
    }

    @Test
    fun calculatePrice_Is_Correct_Below_FirstRateMax() {
        val bill = Bill(50.0)
        val expectedPrice = 50.0 * 2.50 + 20.0  // 125.0 + 20 = 145.0
        assertEquals(expectedPrice, bill.calculatePrice(), 0.01)
    }

    @Test
    fun calculatePrice_Is_Correct_At_FirstRateMax() {
        val bill = Bill(100.0)
        val expectedPrice = 100.0 * 2.50 + 20.0  // 250.0 + 20 = 270.0
        assertEquals(expectedPrice, bill.calculatePrice(), 0.01)
    }

    @Test
    fun calculatePrice_Is_Correct_Above_FirstRateMax() {
        val bill = Bill(150.0)
        val expectedPrice = (100.0 * 2.50) + (50.0 * 4.0) + 20.0  // 250.0 + 200.0 + 20 = 470.0
        assertEquals(expectedPrice, bill.calculatePrice(), 0.01)
    }

    @Test
    fun calculatePrice_Is_Correct_Just_Above_FirstRateMax() {
        val bill = Bill(101.0)
        val expectedPrice = (100.0 * 2.50) + (1.0 * 4.0) + 20.0  // 250.0 + 4.0 + 20 = 274.0
        assertEquals(expectedPrice, bill.calculatePrice(), 0.01)
    }

    @Test
    fun calculatePrice_Is_Correct_High_Quantity() {
        val bill = Bill(500.0)
        val expectedPrice = (100.0 * 2.50) + (400.0 * 4.0) + 20.0  // 250.0 + 1600.0 + 20 = 1870.0
        assertEquals(expectedPrice, bill.calculatePrice(), 0.01)
    }
}
