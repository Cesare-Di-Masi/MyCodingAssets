class Bill(quantityM3Val:Double) {

    val fixedRate=20.0
    val firstRateMax=100.0
    val firstRate=2.50
    val excessRate=4.0

    init {
        require(quantityM3Val>0.0){"illegal quantity"}
    }

    val quantityM3=quantityM3Val

    fun calculatePrice():Double{
        return when{
            quantityM3<=firstRateMax-> firstRate*quantityM3+fixedRate
            else-> (quantityM3-100.0)*excessRate+fixedRate+100.0*firstRate}
    }

}