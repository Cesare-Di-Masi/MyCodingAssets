import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*


class TemperatureSensorTest {

    @Test
    fun getCOSTANTE_CONVERSIONE_CELSIUS_KELVIN_MORE_THAN_273() {
        assertThrows<IllegalArgumentException>{ val sensorTest=TemperatureSensor(-273.5) }
    }

    @Test
    fun temperature_Farheneith_Is_Correct(){

        val temperatureTest=TemperatureSensor(1.0)
        assertEquals(33.0, temperatureTest.temperatureF)

    }

    @Test
    fun temperature_Kelvin_Is_Correct(){

        val temperatureTest=TemperatureSensor(1.0)
        assertEquals(274.15, temperatureTest.temperatureK)

    }
}