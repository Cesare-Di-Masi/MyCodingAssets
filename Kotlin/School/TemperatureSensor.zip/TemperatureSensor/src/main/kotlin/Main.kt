import java.lang.Exception

fun main(args: Array<String>) {
    try {
        val sensore=TemperatureSensor(1.0)

        println(sensore.temperatureC)
        println(sensore.temperatureF)
        println(sensore.temperatureK)
    }catch (EX:Exception){
        println(EX.message)
    }
    println("programma terminato")
}